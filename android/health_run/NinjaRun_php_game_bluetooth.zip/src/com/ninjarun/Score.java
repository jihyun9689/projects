package com.ninjarun;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.webkit.WebView;

public class Score extends Activity {
	WebView browser;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_score);
		
		browser=(WebView)findViewById(R.id.webkit);
		browser.getSettings().setDefaultTextEncodingName("UTF-8");  

		
 		browser.loadUrl("http://218.159.230.107/getscore.php");
	}



}
