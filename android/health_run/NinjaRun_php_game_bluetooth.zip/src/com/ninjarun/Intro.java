package com.ninjarun;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.BounceInterpolator;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;

public class Intro extends Activity {
	ImageView introcoma;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_intro);
		introcoma = (ImageView) findViewById(R.id.introcoma);
		AnimationSet ani11 = null;
		ani11 = new AnimationSet(true);
		ani11.setInterpolator(new BounceInterpolator());

		Animation alpha112 = new ScaleAnimation(0, 1.5f, 0, 1.5f,
				Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF,
				0.5f);

		
		alpha112.setDuration(1000);
		alpha112.setStartOffset(1000);
		ani11.setFillAfter(true);
		ani11.addAnimation(alpha112);
		introcoma.startAnimation(ani11);

	
		

		Handler handler = new Handler() {
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				// startActivity(intent);
				startActivity(new Intent(Intro.this,
						login.class));
				finish();
			}
		};
		handler.sendEmptyMessageDelayed(0, 3000);
	}
	}
