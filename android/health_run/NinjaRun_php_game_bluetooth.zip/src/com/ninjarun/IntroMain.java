package com.ninjarun;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.webkit.WebView;

public class IntroMain extends Activity {
	WebView browser;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_intro_main);
		

		browser=(WebView)findViewById(R.id.webkit);
		browser.getSettings().setDefaultTextEncodingName("UTF-8");  
		

		browser.loadUrl("http://218.159.230.107/getscore.php");
	}

	public void mOnClick(View v) {

		switch (v.getId()) {

		case R.id.controlbtn:
			Intent a = new Intent(IntroMain.this, FirstActivity.class);
			startActivity(a);
			a.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

		break;
		case R.id.optionsbtn:
			AlertDialog ab = new AlertDialog.Builder(this)
					.setTitle("Option")
					.setMessage("선택해주세요")
					.setPositiveButton("조작방법",

					new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int which) {

							Intent b = new Intent(IntroMain.this, Menual.class);
							startActivity(b);
							b.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						}
					})
					.setNegativeButton("게임방법",
							new DialogInterface.OnClickListener() {
								public void onClick(DialogInterface dialog,
										int which) {
									Intent c = new Intent(IntroMain.this,
											Menual2.class);
									startActivity(c);
									c.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
								}
							})

					.create();

			ab.setCanceledOnTouchOutside(false);
			ab.show();

			break;

		case R.id.scorebtn:

			Intent d = new Intent(IntroMain.this, Score.class);
			startActivity(d);
			d.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

			break;
		case R.id.profilebtn:

			// // 알림창을 띄움: 시작 ////
			AlertDialog di = new AlertDialog.Builder(this)

					.setMessage(
							"\nDirector Kim Ji Hun "
									+ "\nDirector Sim  Min  Gue "
									+ "\nDirector Yun  Jo O"
									+ "\nDirector Song  Hea Jin"
									+ "\nDesigner Choi Jin Eun"
									+ "\n\ncopyright(c)2014 \nAll rights reserved by COMA")
					.create();
			di.setCanceledOnTouchOutside(true);
			di.show();

			// //알림창을 띄움:끝////

			/*
			 * Intent c = new Intent(FightRobotActivity.this, Popup.class);
			 * startActivity(c); c.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			 */
			break;

		}

	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
	  if ( event.getAction() == KeyEvent.ACTION_DOWN )
	  {
	      if ( keyCode == KeyEvent.KEYCODE_BACK )
	      {
	    	  AlertDialog di = new AlertDialog.Builder(this)
	    	  .setTitle("게임 종료")
	    	  .setMessage("게임을 종료하시겠습니까?")
	    	  .setPositiveButton("종료", 

	    	                new DialogInterface.OnClickListener() {
	    	    public void onClick(DialogInterface dialog, int which) {
	    	    finish();
	    	   }
	    	  })
	    	  .setNegativeButton("더할래", null) 

	    	  .create();


	    	  di.setCanceledOnTouchOutside(false);
	    	  di.show(); 




	      }
	     
	  }
	  return super.onKeyDown(keyCode, event);
	}

	
	
}
