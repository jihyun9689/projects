package com.ninjarun;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;


public class login extends Activity {
	MediaPlayer player;
	String mSdPath;
	ImageView mAnimTarget1, mAnimTarget2,mAnimTarget3,mAnimTarget4,mAnimTarget5,mAnimTarget6,mAnimTarget7,mAnimTarget8,mAnimTarget10,mAnimTarget11,mAnimTarget12,mAnimTarget13;
	
	
	public static final int DURATION_TIME = 1000;
	public static final int RIGHT = 5;
	public static final int LEFT = -2;

	
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
	
		
		Button logbutton = (Button)findViewById(R.id.logbtn);
		logbutton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
			
			
				
				Intent intent = new Intent(login.this,IntroMain.class);	
				startActivity(intent);
				//overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
				
				
			}
		});
		
		//��1
		mAnimTarget1 = (ImageView)findViewById(R.id.flower1);
        AnimationSet ani1 = null;
     	ani1 = new AnimationSet(true);
     	ani1.setInterpolator(new LinearInterpolator());
     	
     	Animation Rotate1 = new RotateAnimation(LEFT, RIGHT, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 1);
     	Rotate1.setDuration(DURATION_TIME);
     	Rotate1.setRepeatCount(Animation.INFINITE);
     	Rotate1.setRepeatMode(Animation.REVERSE);
     	ani1.addAnimation(Rotate1);
        mAnimTarget1.startAnimation(ani1);
        
        //��2
		
        mAnimTarget2 = (ImageView)findViewById(R.id.flower2);
        AnimationSet ani2 = null;
     	ani2 = new AnimationSet(true);
     	ani2.setInterpolator(new LinearInterpolator());
     	
     	Animation Rotate2 = new RotateAnimation(LEFT, RIGHT, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 1);
     	Rotate2.setDuration(DURATION_TIME);
     	Rotate2.setRepeatCount(Animation.INFINITE);
     	Rotate2.setRepeatMode(Animation.REVERSE);
     	ani2.addAnimation(Rotate1);
        mAnimTarget2.startAnimation(ani2);
        
        //��3
        mAnimTarget3 = (ImageView)findViewById(R.id.flower3);
        AnimationSet ani3 = null;
     	ani3 = new AnimationSet(true);
     	ani3.setInterpolator(new LinearInterpolator());
     	
     	Animation Rotate3 = new RotateAnimation(LEFT, RIGHT, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 1);
     	Rotate3.setDuration(DURATION_TIME);
     	Rotate3.setRepeatCount(Animation.INFINITE);
     	Rotate3.setRepeatMode(Animation.REVERSE);
     	ani3.addAnimation(Rotate3);
        mAnimTarget3.startAnimation(ani3);
        
        //��4
        mAnimTarget4 = (ImageView)findViewById(R.id.flower4);
        AnimationSet ani4 = null;
     	ani4 = new AnimationSet(true);
     	ani4.setInterpolator(new LinearInterpolator());
     	
     	Animation Rotate4 = new RotateAnimation(LEFT, RIGHT, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 1);
     	Rotate4.setDuration(DURATION_TIME);
     	Rotate4.setRepeatCount(Animation.INFINITE);
     	Rotate4.setRepeatMode(Animation.REVERSE);
     	ani4.addAnimation(Rotate4);
        mAnimTarget4.startAnimation(ani4);
        
        //��5
        mAnimTarget5 = (ImageView)findViewById(R.id.flower5);
        AnimationSet ani5 = null;
     	ani5 = new AnimationSet(true);
     	ani5.setInterpolator(new LinearInterpolator());
     	
     	Animation Rotate5 = new RotateAnimation(LEFT, RIGHT, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 1);
     	Rotate5.setDuration(DURATION_TIME);
     	Rotate5.setRepeatCount(Animation.INFINITE);
     	Rotate5.setRepeatMode(Animation.REVERSE);
     	ani5.addAnimation(Rotate5);
        mAnimTarget5.startAnimation(ani5);
        
        //��6
        mAnimTarget6 = (ImageView)findViewById(R.id.flower6);
        AnimationSet ani6 = null;
     	ani6 = new AnimationSet(true);
     	ani6.setInterpolator(new LinearInterpolator());
     	
     	Animation Rotate6 = new RotateAnimation(LEFT, RIGHT, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 1);
     	Rotate6.setDuration(DURATION_TIME);
     	Rotate6.setRepeatCount(Animation.INFINITE);
     	Rotate6.setRepeatMode(Animation.REVERSE);
     	ani6.addAnimation(Rotate6);
        mAnimTarget6.startAnimation(ani6);
        
        //��7
        mAnimTarget7 = (ImageView)findViewById(R.id.flower7);
        AnimationSet ani7 = null;
     	ani7 = new AnimationSet(true);
     	ani7.setInterpolator(new LinearInterpolator());
     	
     	Animation Rotate7 = new RotateAnimation(LEFT, RIGHT, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 1);
     	Rotate7.setDuration(DURATION_TIME);
     	Rotate7.setRepeatCount(Animation.INFINITE);
     	Rotate7.setRepeatMode(Animation.REVERSE);
     	ani7.addAnimation(Rotate7);
        mAnimTarget7.startAnimation(ani7);
        
        //��8
        mAnimTarget8 = (ImageView)findViewById(R.id.flower8);
        AnimationSet ani8 = null;
     	ani8 = new AnimationSet(true);
     	ani8.setInterpolator(new LinearInterpolator());
     	
     	Animation Rotate8 = new RotateAnimation(LEFT, RIGHT, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 1);
     	Rotate8.setDuration(DURATION_TIME);
     	Rotate8.setRepeatCount(Animation.INFINITE);
     	Rotate8.setRepeatMode(Animation.REVERSE);
     	ani8.addAnimation(Rotate8);
        mAnimTarget8.startAnimation(ani8);
        
        
        //����1
        
        mAnimTarget10 = (ImageView)findViewById(R.id.cloud1);
        AnimationSet ani10 = null;
     	ani10 = new AnimationSet(true);
     	ani10.setInterpolator(new LinearInterpolator());
     	    	
     	Animation trans11 = new TranslateAnimation(Animation.RELATIVE_TO_SELF,0,Animation.RELATIVE_TO_SELF,7,
    			Animation.RELATIVE_TO_SELF,0,Animation.RELATIVE_TO_SELF,0);
     	trans11.setDuration(70000);
     	ani10.addAnimation(trans11);
     	
        mAnimTarget10.startAnimation(ani10);
	
        
        trans11.setAnimationListener(new Animation.AnimationListener() {
    		public void onAnimationStart(Animation animation) {}
    		public void onAnimationRepeat(Animation animation) {}
    		public void onAnimationEnd(Animation animation) {
    			AnimationSet ani10 = null;
    			ani10 = new AnimationSet(true);
    	     	ani10.setInterpolator(new LinearInterpolator());
    			
    			Animation trans12 = new TranslateAnimation(Animation.RELATIVE_TO_SELF,-1,Animation.RELATIVE_TO_SELF,7,
    	    			Animation.RELATIVE_TO_SELF,0,Animation.RELATIVE_TO_SELF,0);
    			trans12.setDuration(80000);
    			trans12.setRepeatCount(Animation.INFINITE);
    			trans12.setRepeatMode(Animation.RESTART);
    	     	ani10.addAnimation(trans12);
    	     	
    	     	mAnimTarget10.startAnimation(ani10);
    		}
    	});
        
        
        //����2
        
        mAnimTarget11 = (ImageView)findViewById(R.id.cloud2);
        AnimationSet ani11 = null;
     	ani11 = new AnimationSet(true);
     	ani11.setInterpolator(new LinearInterpolator());
     	    	
     	Animation trans21 = new TranslateAnimation(Animation.RELATIVE_TO_SELF,0,Animation.RELATIVE_TO_SELF,11,
    			Animation.RELATIVE_TO_SELF,0,Animation.RELATIVE_TO_SELF,0);
     	trans21.setDuration(110000);
     	ani11.addAnimation(trans21);
     	
        mAnimTarget11.startAnimation(ani11);
	
        
        trans21.setAnimationListener(new Animation.AnimationListener() {
    		public void onAnimationStart(Animation animation) {}
    		public void onAnimationRepeat(Animation animation) {}
    		public void onAnimationEnd(Animation animation) {
    			AnimationSet ani11 = null;
    			ani11 = new AnimationSet(true);
    	     	ani11.setInterpolator(new LinearInterpolator());
    			
    			Animation trans22 = new TranslateAnimation(Animation.RELATIVE_TO_SELF,-8,Animation.RELATIVE_TO_SELF,11,
    	    			Animation.RELATIVE_TO_SELF,0,Animation.RELATIVE_TO_SELF,0);
    			trans22.setDuration(1900000);
    			trans22.setRepeatCount(Animation.INFINITE);
    			trans22.setRepeatMode(Animation.RESTART);
    	     	ani11.addAnimation(trans22);
    	     	
    	     	mAnimTarget11.startAnimation(ani11);
    		}
    	});
        
        //����3
        
        mAnimTarget12 = (ImageView)findViewById(R.id.cloud3);
        AnimationSet ani12 = null;
     	ani12 = new AnimationSet(true);
     	ani12.setInterpolator(new LinearInterpolator());
     	    	
     	Animation trans31 = new TranslateAnimation(Animation.RELATIVE_TO_SELF,0,Animation.RELATIVE_TO_SELF,5,
    			Animation.RELATIVE_TO_SELF,0,Animation.RELATIVE_TO_SELF,0);
     	trans31.setDuration(50000);
     	ani12.addAnimation(trans31);
     	
        mAnimTarget12.startAnimation(ani12);
	
        
        trans31.setAnimationListener(new Animation.AnimationListener() {
    		public void onAnimationStart(Animation animation) {}
    		public void onAnimationRepeat(Animation animation) {}
    		public void onAnimationEnd(Animation animation) {
    			AnimationSet ani12 = null;
    			ani12 = new AnimationSet(true);
    	     	ani12.setInterpolator(new LinearInterpolator());
    			
    			Animation trans32 = new TranslateAnimation(Animation.RELATIVE_TO_SELF,-5,Animation.RELATIVE_TO_SELF,5,
    	    			Animation.RELATIVE_TO_SELF,0,Animation.RELATIVE_TO_SELF,0);
    			trans32.setDuration(100000);
    			trans32.setRepeatCount(Animation.INFINITE);
    			trans32.setRepeatMode(Animation.RESTART);
    	     	ani12.addAnimation(trans32);
    	     	
    	     	mAnimTarget12.startAnimation(ani12);
    		}
    	});
        
        
        //����4
        
        mAnimTarget13 = (ImageView)findViewById(R.id.cloud4);
        AnimationSet ani13 = null;
     	ani13 = new AnimationSet(true);
     	ani13.setInterpolator(new LinearInterpolator());
     	    	
     	Animation trans41 = new TranslateAnimation(Animation.RELATIVE_TO_SELF,0,Animation.RELATIVE_TO_SELF,1.5f,
    			Animation.RELATIVE_TO_SELF,0,Animation.RELATIVE_TO_SELF,0);
     	trans41.setDuration(15000);
     	ani13.addAnimation(trans41);
     	
        mAnimTarget13.startAnimation(ani13);
	
        
        trans41.setAnimationListener(new Animation.AnimationListener() {
    		public void onAnimationStart(Animation animation) {}
    		public void onAnimationRepeat(Animation animation) {}
    		public void onAnimationEnd(Animation animation) {
    			AnimationSet ani13 = null;
    			ani13 = new AnimationSet(true);
    	     	ani13.setInterpolator(new LinearInterpolator());
    			
    			Animation trans42 = new TranslateAnimation(Animation.RELATIVE_TO_SELF,-17,Animation.RELATIVE_TO_SELF,1.5f,
    	    			Animation.RELATIVE_TO_SELF,0,Animation.RELATIVE_TO_SELF,0);
    			trans42.setDuration(185000);
    			trans42.setRepeatCount(Animation.INFINITE);
    			trans42.setRepeatMode(Animation.RESTART);
    	     	ani13.addAnimation(trans42);
    	     	
    	     	mAnimTarget13.startAnimation(ani13);
    		}
    	});
        
	}

	protected void onStop() {
		super.onStop();
		this.finish();
	}
	
			
}

