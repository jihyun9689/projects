package com.baerang.baerang.util;

public class ServerUtil {
	public static final String SERVER_URL = "http://bearang.elasticbeanstalk.com/bearang/";
//	public static final String SERVER_URL = "http://192.168.202.146/webData/";
}
