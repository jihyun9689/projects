package com.baerang.baerang.feature.login;

import android.os.Handler;
import android.util.Log;

import com.baerang.baerang.util.CookieManagerBaerang;
import com.baerang.baerang.util.NetManager1;
import com.baerang.baerang.util.ServerUtil;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

/**
 * Created by kim on 2016-01-11.
 */

class RequestThread extends Thread {
    static final String TAG = "RequestThread";
    List<NameValuePair> nameValue;
    String data = "";
    Handler handler;

    public RequestThread(List<NameValuePair> nameValue, Handler handler){
        this.nameValue = nameValue ;
        this.handler = handler;
    }

    public void run(){
        String url = ServerUtil.SERVER_URL + "member";
        Log.e(TAG, url);

        HttpClient client = NetManager1.getHttpClient();
        HttpPost post = NetManager1.getPost(url);

        HttpResponse response = null;
        BufferedReader br = null;
        StringBuffer sb = null;

        String line = "";
        try{
            Log.v(TAG, "process");
            UrlEncodedFormEntity entity = new UrlEncodedFormEntity(nameValue);
            Log.v(TAG, entity + "");
            post.setEntity(entity);

            response = client.execute(post);
            int code = response.getStatusLine().getStatusCode();
            Log.v(TAG, "process code : " + code);
            switch(code){
                case 200 :
//                  br = new BufferedReader(new InputStreamReader(response.getEntity().getContent(),"euc-kr"));
                    br = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
                    sb = new StringBuffer();
                    while((line = br.readLine())!= null){
                        sb.append(line);
                    }
                    Log.v(TAG, "process msg : " + sb);
                    data = sb.toString();
                    requestHandlerSendMessage(data);
                    break;
                default :
                    handler.sendEmptyMessage(SignUpActivity.RequestHandler.TIME_OUT_ERROR);
            }

        }catch(Exception e){
            Log.v(TAG, "login parser error : " + e);
            handler.sendEmptyMessage(SignUpActivity.RequestHandler.PARSE_ERROR);
        }finally{
            CookieManagerBaerang.updateCookie(client);
            try{
                br.close();
            }catch(Exception e){}

        }
    }

    private void requestHandlerSendMessage(String data){
        if(data.equals("id_exist")){
            handler.sendEmptyMessage(SignUpActivity.RequestHandler.ID_EXIST);
        }
        else if(data.equals("update_id")){
            handler.sendEmptyMessage(SignUpActivity.RequestHandler.UPDATE_ID);
        }
        else if(data.equals("no_id")){
            handler.sendEmptyMessage(SignUpActivity.RequestHandler.NO_ID);
        }
        else if(data.equals("success")){
            handler.sendEmptyMessage(SignUpActivity.RequestHandler.SUCCESS);
        }
        else if(data.equals("false_pw")){
            handler.sendEmptyMessage(SignUpActivity.RequestHandler.FALSE_PW);
        }
        else if(data.equals("valide_route")){
            handler.sendEmptyMessage(SignUpActivity.RequestHandler.VALIDE_ROUTE);
        }
    }

}

