package com.baerang.baerang.database;

import android.util.Log;

import java.util.Calendar;

/**
 * Created by kim on 2015-12-09.
 */
public class BaerangData {
    private String id;
    private String name;
    private String macAddress;
    private String gps;
    private String time;

    public BaerangData(String name, String macAddress, String gps){
        this.name = name;
        this.macAddress = macAddress;
        this.gps = gps;
        setTime();
    }

    private void setTime(){

        Calendar calendar = Calendar.getInstance();
        time = calendar.getTime().toString();
        Log.i("aaaa", time);
    }

    public void setID(int id){
        this.id = String.valueOf(id);
    }
    public String getID(){ return id; }
    public String getName(){ return name; }
    public String getMacAddress(){ return macAddress; }
    public String getGPS(){ return gps; }
    public String getTime(){ return time; }

}
