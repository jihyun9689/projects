package com.baerang.baerang.util;

import android.content.Context;
import android.util.Log;

import com.baerang.baerang.LogManager;

import org.apache.http.client.CookieStore;
import org.apache.http.client.HttpClient;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.DefaultHttpClient;

import java.util.List;

/**
 * Created by kim on 2016-01-13.
 */
public class CookieManagerBaerang {
    static final String TAG = "CookieManagerBaerang";

    public final static Cookie getCookie(HttpClient httpClient){
        List<Cookie>cookies =((DefaultHttpClient) httpClient).getCookieStore().getCookies();
        return cookies.get(0);
    }

    public static void updateCookie(HttpClient httpClient){
        LogManager.printLog(TAG, "updateCookie");
        CookieStore cookieStore =((DefaultHttpClient) httpClient).getCookieStore();
        List<Cookie> cookieList=cookieStore.getCookies();

        if (!cookieList.isEmpty()) {
            for (int i = 0; i < cookieList.size(); i++) {
                // cookie = cookies.get(i);
                String cookieString = cookieList.get(i).getName() + "="
                        + cookieList.get(i).getValue();
                LogManager.printLog(TAG, cookieString);
            }
        }

    }
}

