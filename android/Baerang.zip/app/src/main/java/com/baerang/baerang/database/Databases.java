package com.baerang.baerang.database;


/**
 * Created by kim on 2015-11-03.
 */
public class Databases {
    public static final class CreateDB{
        public  static final String _TABLENAME = "baerang";
        public  static final String ID = "_id";
        public  static final String NAME = "name";
        public  static final String MACADDRESS = "macaddress";
        public  static final String GPS = "gps";
        public  static final String TIME = "time";
        // table 질의를 수향할 테이블 이름
        public  static final String _CREATE =
                "CREATE TABLE "+ _TABLENAME+ "("
                +ID+ " TEXT NOT NULL, "
                + NAME + " TEXT NOT NULL,"
                + MACADDRESS + " TEXT NOT NULL,"
                + GPS + " TEXT NOT NULL,"
                + TIME + " TEXT NOT NULL"
                +" );";
        //autoincrement란 속성은 DATA를 DB에 넣을 때 자동으로 "+1"을 증가 시켜주는 주어 DATA를 식별 할 수 있는 고유 번호를 부여하는 속성입니다.
    }
}
