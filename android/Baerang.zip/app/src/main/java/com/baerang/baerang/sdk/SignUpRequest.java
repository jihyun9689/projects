package com.baerang.baerang.sdk;


public class SignUpRequest {

    private SignUpRequest(String email, String password) {
        this.email = email;
        this.password = password;
    }

    @KeyName("email")
    private String email;

    @KeyName("password")
    private String password;

    public static class Builder {
        private String email;
        private String password;

        public Builder setEmail(String email) {
            this.email = email;
            return this;
        }

        public Builder setPassword(String password) {
            this.password = password;
            return this;
        }

        public SignUpRequest build() {
            return new SignUpRequest(email, password);
        }
    }
}
