package com.baerang.baerang;

import android.util.Log;


public class LogManager {
    private static final String _TAG = "BAERANG";

    public static final boolean _DEBUG = true;

    public static void printLog(String activityName, String text)
    {
    	if ( _DEBUG )
    	{
            Log.d(_TAG,activityName + " : " + text);
    	}
    }
    
    
    public static void printError(String activityName, String text)
    {	
    	if(_DEBUG)
            Log.e(_TAG,"*** Error ***" + activityName + " : " + text);
    }

}
