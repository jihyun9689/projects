package com.baerang.baerang.feature.main;

import android.app.TabActivity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.widget.TabHost;

import com.baerang.baerang.R;

import java.sql.SQLDataException;

/**
 * Created by kim on 2015-12-09.
 */
public class MainActivity extends TabActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Resources res = this.getResources();
        TabHost tabhost = this.getTabHost();
        TabHost.TabSpec spec;
        Intent intent = null;

        intent = new Intent().setClass(this, DistanceActivity.class);
        spec = tabhost.newTabSpec("distance").setIndicator("distance", res.getDrawable(R.drawable.tabfoot)).setContent(intent);
        tabhost.addTab(spec);

        intent = new Intent().setClass(this, StuffListActivity.class);
        spec = tabhost.newTabSpec("stuff").setIndicator("stuff", res.getDrawable(R.drawable.tabfoot)).setContent(intent);
        tabhost.addTab(spec);

        intent = new Intent().setClass(this, RealTimeActivity.class);
        spec = tabhost.newTabSpec("real time").setIndicator("real time", res.getDrawable(R.drawable.tabfoot)).setContent(intent);
        tabhost.addTab(spec);

        tabhost.setCurrentTab(0);


    }
}
