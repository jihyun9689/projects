package com.baerang.baerang.feature.main.infoStuff;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.baerang.baerang.R;
import com.baerang.baerang.database.DbOpenHelper;

import java.sql.SQLDataException;

/**
 * Created by kim on 2015-12-13.
 */
public class InfoStuffActivity extends Activity {
    DbOpenHelper dbOpenHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_infostuff);
        TextView[] textView = new TextView[4];

        textView[0] = (TextView) findViewById(R.id.text_info_name);
        textView[1] = (TextView) findViewById(R.id.text_info_mac);
        textView[2] = (TextView) findViewById(R.id.text_info_gps);
        textView[3] = (TextView) findViewById(R.id.text_info_time);

        Button btn_delete = (Button) findViewById(R.id.btn_info_delete);

        Intent intentInfo = getIntent();
        final int index = intentInfo.getExtras().getInt("index");

        dbOpenHelper = new DbOpenHelper(this);

        try {
            dbOpenHelper.open();
        } catch (SQLDataException e) {
            e.printStackTrace();
        }

        Cursor cursor = dbOpenHelper.readTable(index);

        for (int i = 0 ; i < 4 ; i ++){
            textView[i].setText(cursor.getString(i));
        }

        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(InfoStuffActivity.this);

                // set title
                alertDialogBuilder.setTitle("Your Title");

                // set dialog message
                alertDialogBuilder
                        .setMessage("Click yes to exit!")
                        .setCancelable(false)
                        .setPositiveButton("Yes",new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog,int id) {
                                // if this button is clicked, close
                                // current activity

                                dbOpenHelper.deleteTable(index);
                                InfoStuffActivity.this.finish();
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // if this button is clicked, just close
                                // the dialog box and do nothing
                                dialog.cancel();
                            }
                        });

                // create alert dialog
                AlertDialog alertDialog = alertDialogBuilder.create();

                // show it
                alertDialog.show();
            }
        });
    }
}
