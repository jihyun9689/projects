package com.baerang.baerang.service;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.widget.Toast;

import com.baerang.baerang.LogManager;
import com.baerang.baerang.R;
import com.baerang.baerang.feature.main.MainActivity;

import java.util.HashMap;
import java.util.Random;

public class BluetoothLeService extends Service {
    static final String TAG = "BluetoothLeService";


    static public BluetoothAdapter mBluetoothAdapter;
    public ScanThread scanThread;
    private final Random mGenerator = new Random();


    @Override
    public void onStart(Intent intent, int startId) {

        if (mBluetoothAdapter == null) {
            Toast.makeText(this, R.string.error_bluetooth_not_supported, Toast.LENGTH_SHORT).show();
            return;
        }

        scanNotification();
        scanThread = new ScanThread(true);
        scanThread.start();

        super.onStart(intent, startId);

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public boolean stopService(Intent name) {
        scanThread.stopThread();
        stopSelf();

        return super.stopService(name);
    }

    @Override
    public void onDestroy() {
        scanThread.stopThread();
        stopSelf();
        super.onDestroy();
        LogManager.printLog(TAG, "onDestroy()");
    }

    @Override
    public IBinder onBind(Intent intent) {
        Toast.makeText(getApplicationContext(), "binding", Toast.LENGTH_SHORT).show();
        return new LocalBinder();
    }


    @Override
    public void onRebind(Intent intent) {

        super.onRebind(intent);
    }

    @Override
    public boolean onUnbind(Intent intent) {

        return true;
    }


    class ScanThread extends Thread {
        boolean enable;
        public ScanThread(boolean enable){
            this.enable = enable;
        }
        BlueCallBack blueCallBack = new BlueCallBack();

        public void stopThread(){
            enable = false;
        }

        @Override
        public void run() {
            super.run();

            while (enable) {
                try { Thread.sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                mBluetoothAdapter.startLeScan(blueCallBack);
                LogManager.printLog(TAG, "scanning");
            }

            mBluetoothAdapter.stopLeScan(blueCallBack);
            mBluetoothAdapter = null;
        }
    }

    public static class BlueCallBack implements BluetoothAdapter.LeScanCallback{
        public static HashMap<BluetoothDevice, Integer> hmap;
        public static int rssi = 0;
        @Override
        public void onLeScan(BluetoothDevice bluetoothDevice, int rssi, byte[] bytes) {
            hmap.put(bluetoothDevice, rssi);
            LogManager.printLog(TAG,"rssi : "+rssi);
        }
    }

    private void scanNotification(){
        Notification notification = new Notification(R.drawable.tabfoot, "배랑",
                System.currentTimeMillis());
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);

        //setLatestEventInfo는 23 version 미만에서만 작동
        notification.setLatestEventInfo(this, "배랑 물건 스캔",
                "물건 스캔 중", pendingIntent);
        startForeground(1234, notification);
    }

    public class LocalBinder extends Binder {
        public BluetoothLeService getService() {
            // Return this instance of LocalService so clients can call public methods
            return BluetoothLeService.this;
        }
    }
}
