package com.baerang.baerang.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;

import com.baerang.baerang.LogManager;

import java.io.File;
import java.sql.SQLDataException;

/**
 * Created by kim on 2015-11-11.
 */
public class DbOpenHelper {
    private static final String TAG = "DbOpenHelper";
    private static final String DATABASE_NAME = "baerang.db";
    private static final int DATABASE_VERSION = 1;
    public static SQLiteDatabase mDB;
    //데이터베이스를 다루는 작업(추가, 삭제, 수정,쿼리)를 담당한다.
    private DatabaseHelper mDBHelper;
    //데이터베이스의 생성, 열기, 업그레이드를 담당한다.
    private Context context;
    private static final String FILE_PATH = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + DATABASE_NAME;

    private class DatabaseHelper extends SQLiteOpenHelper{
        public DatabaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
            super(context, FILE_PATH, factory, version);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(Databases.CreateDB._CREATE);
        }

        // 버전이 업데이트 되었을 경우 DB를 다시 만들어 줍니다. DATABASE_VERSION = 1,2,3 이런식으로 수정해 주시면
        // 자동으로 기존의 TABLE을 삭제하고 새로운 TABLE을 만들어 줍니다.
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXIST " +Databases.CreateDB._TABLENAME);
            onCreate(db);
        }
    }

    public DbOpenHelper(Context context){
        this.context = context;

    }

    public DbOpenHelper open() throws SQLDataException{
        mDBHelper = new DatabaseHelper(context, DATABASE_NAME, null, DATABASE_VERSION);
        //mDB = mDBHelper.getWritableDatabase();
        // DB를 사용하기위해 생성하거나 열어 줍니다. DB를 읽거나 쓸수 있는 권한을 부여 합니다.

        return this;
    }

    public void close(){
        mDB.close();
    }

    public void createTable(BaerangData gpsData){
        int total = getTotalCount();
        gpsData.setID(total + 1);
        mDB = mDBHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(Databases.CreateDB.ID, gpsData.getID());
        values.put(Databases.CreateDB.NAME, gpsData.getName());
        values.put(Databases.CreateDB.MACADDRESS, gpsData.getMacAddress());
        values.put(Databases.CreateDB.GPS, gpsData.getGPS());
        values.put(Databases.CreateDB.TIME, gpsData.getTime());

        // insert book
        mDB.insert(Databases.CreateDB._TABLENAME, null, values);

        // close database transaction
        mDB.close();
    }

    /*
    public void insert (Medicine medicine){
        ContentValues values = new ContentValues();
        values.put(Databases.CreateDB.TITLE, medicine.getMeddicineTitle());
        mDB.insert(Databases.CreateDB._TABLENAME, null, values);
        mDB.close();
    }
   */

    public void deleteTable(int index){
        mDB = mDBHelper.getWritableDatabase();
        mDB.execSQL("delete from baerang where _id = " + index);
        mDB.execSQL("update baerang set _id = _id - 1 where _id > "+ index);
        mDB.close();
    }

    public Cursor readTable(int index){
        mDB = mDBHelper.getReadableDatabase();
        Cursor cursor = mDB.query(Databases.CreateDB._TABLENAME,
                new String[]{Databases.CreateDB.NAME, Databases.CreateDB.MACADDRESS, Databases.CreateDB.GPS, Databases.CreateDB.TIME},
                Databases.CreateDB.ID +"= ?",
                new String[] {String.valueOf(index)},null, null ,null);

        if(cursor !=null) cursor.moveToFirst();
            //Medicine medicine = new Medicine();
            //LogManager.printLog(TAG, cursor.getString(0) + " " + cursor.getString(1) + " " + cursor.getString(2) + " " + cursor.getString(3));

        mDB.close();
        return cursor;
    }

    public int getTotalCount(){
        mDB = mDBHelper.getReadableDatabase();
        int count = mDB.rawQuery("select * from baerang", null ).getCount();
        mDB.close();
        return count;

    }

    public boolean isHaveSameOne(String addressNumber){
        for(int i = 1 ; i <= getTotalCount(); i ++){
            //LogManager.printLog(TAG, "addressNumber : " + addressNumber + "     readTable(i).getString(1) : " + readTable(i).getString(1));
            if(addressNumber.equals(readTable(i).getString(1))){
                LogManager.printLog(TAG, "addressNumber : " + addressNumber + "     readTable(i).getString(1) : " + readTable(i).getString(1));
                return true;
            }
        }
        mDB.close();
        return false;
    }
}
