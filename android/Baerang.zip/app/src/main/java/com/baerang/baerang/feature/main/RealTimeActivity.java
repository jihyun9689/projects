package com.baerang.baerang.feature.main;

import android.app.Activity;
import android.os.Bundle;

import com.baerang.baerang.R;

/**
 * Created by kim on 2015-12-09.
 */
public class RealTimeActivity extends Activity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_realtime);


    }
}