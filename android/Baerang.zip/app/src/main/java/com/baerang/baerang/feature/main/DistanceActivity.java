package com.baerang.baerang.feature.main;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.SystemClock;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.baerang.baerang.LogManager;
import com.baerang.baerang.R;
import com.baerang.baerang.service.BluetoothLeService;

/**
 * Created by kim on 2015-12-09.
 */
public class DistanceActivity extends Activity{
    static final String TAG = "DistanceActivity";
    private Intent intent = null;
    Switch switchOnOFF;

    BluetoothLeService bluetoothLeService;
    boolean mBound;
    TextView distance_text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_distance);

        switchOnOFF = (Switch) findViewById(R.id.service_onoff_switch);

        Button login = (Button)findViewById(R.id.login);
        distance_text = (TextView)findViewById(R.id.distance_text);

        if(BluetoothLeService.mBluetoothAdapter != null){
            switchOnOFF.setChecked(true);
        }
        else{
            switchOnOFF.setChecked(false);
        }

        switchOnOFF.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked) {

                    final BluetoothManager bluetoothManager =
                            (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
                    BluetoothLeService.mBluetoothAdapter = bluetoothManager.getAdapter();

                    if (BluetoothLeService.mBluetoothAdapter.getState() == BluetoothAdapter.STATE_TURNING_ON || BluetoothLeService.mBluetoothAdapter.getState() == BluetoothAdapter.STATE_ON) {
                        intent = new Intent(DistanceActivity.this, BluetoothLeService.class);
                        startService(intent);
                        getApplicationContext().bindService(intent, mConnection, BIND_AUTO_CREATE);
                        MessageThread messageThread = new MessageThread();
                        messageThread.start();

                        LogManager.printLog(TAG, "BluetoothLeService ON");
                    } else {
                        switchOnOFF.setChecked(false);
                        Toast.makeText(DistanceActivity.this, "turn on Bluetooth", Toast.LENGTH_SHORT).show();
                    }

                } else {
                    getApplicationContext().unbindService(mConnection);
                    stopService(intent);
                    LogManager.printLog(TAG, "BluetoothLeService OFF");
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onPause() {
        super.onPause();

    }


    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            BluetoothLeService.LocalBinder binder = (BluetoothLeService.LocalBinder) iBinder;
            bluetoothLeService = binder.getService();
            mBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            mBound = false;
        }
    };

    private class MessageThread extends Thread{
        @Override
        public void run() {
            while (true){
                if(bluetoothLeService != null){
                    handler.sendEmptyMessage(0);
                }
                SystemClock.sleep(1000L);
            }
        }
    }

    private final Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case 0:
                    int num = BluetoothLeService.BlueCallBack.rssi;
                    distance_text.setText(num + "");
                    break;
            }
        }
    };
}