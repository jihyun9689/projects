package com.baerang.baerang.feature.login;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.baerang.baerang.R;
import com.baerang.baerang.feature.main.MainActivity;
import com.baerang.baerang.sdk.SignUpRequest;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;

import static com.baerang.baerang.R.id.sign_up_use_agreement;

public class SignUpActivity extends Activity {

    private EditText emailEditText;
    private EditText passwordEditText;
    private EditText passwordConfirmEditText;
    private CheckBox useAgreementCheckBox;
    private CheckBox personalInformationCheckBox;

    Context mContext;

    ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        emailEditText = (EditText) findViewById(R.id.sign_up_email_edit_text);
        passwordEditText = (EditText) findViewById(R.id.sign_up_password_edit_text);
        passwordConfirmEditText = (EditText) findViewById(R.id.sign_up_password_confirm_edit_text);
        useAgreementCheckBox = (CheckBox) findViewById(sign_up_use_agreement);
        personalInformationCheckBox = (CheckBox) findViewById(R.id.sign_up_personal_information);

        mContext = getBaseContext();

        findViewById(R.id.sign_up_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(checkValidForm()){
                    dialog = ProgressDialog.show(SignUpActivity.this, "", "로딩중.....");
                    List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
                    //key, value
                    nameValuePairs.add(new BasicNameValuePair( "action", "signup" ));
                    nameValuePairs.add( new BasicNameValuePair( "id", emailEditText.getText().toString() ) ) ;
                    nameValuePairs.add( new BasicNameValuePair( "pw", passwordEditText.getText().toString() ) ) ;

                    new RequestThread(nameValuePairs, new RequestHandler()).start();
                }
            }
        });

        findViewById(R.id.back_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

//    public void signUpSuccess(SignUpResult user) {
//        setResult(RESULT_OK);
//        finish();
//    }
//
//    public boolean signUpFail(CErrorCause errorCause) {
//        switch (errorCause) {
//            case ELEMENT_ALREADY_EXISTS: {
//                Toast.makeText(mContext, R.string.sign_up_error_message_element_already_exists, Toast.LENGTH_SHORT).show();
//                return true;
//            }
//        }
//
//        return false;
//    }

//    private SignUpRequest buildSignUpRequest() {
//        String email = emailEditText.getText().toString();
//        String password = passwordEditText.getText().toString();
//
//        SignUpRequest.Builder builder = new SignUpRequest.Builder();
//        return builder.setEmail(email)
//                .setPassword(password)
//                .build();
//    }

    private boolean checkValidForm() {
        String email = emailEditText.getText().toString();
        String password = passwordEditText.getText().toString();
        String passwordConfirm = passwordConfirmEditText.getText().toString();

        if (email == null || email.length() == 0) {
            Toast.makeText(mContext, R.string.sign_up_error_message_email, Toast.LENGTH_SHORT).show();
            return false;
        }

        if (password == null || password.length() == 0) {
            Toast.makeText(mContext, R.string.sign_up_error_message_password, Toast.LENGTH_SHORT).show();
            return false;
        }

        if (passwordConfirm == null || passwordConfirm.length() == 0) {
            Toast.makeText(mContext, R.string.sign_up_error_message_password_confirm, Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!password.equals(passwordConfirm)) {
            Toast.makeText(mContext, R.string.sign_up_error_message_password_confirm, Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!useAgreementCheckBox.isChecked() || !personalInformationCheckBox.isChecked()) {
            Toast.makeText(mContext, R.string.sign_up_error_message_use_agreement, Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    public class RequestHandler extends Handler {
        static final int ID_EXIST = 0;
        static final int UPDATE_ID = 1;
        static final int NO_ID = 2;
        static final int SUCCESS = 3;
        static final int FALSE_PW = 4;
        static final int VALIDE_ROUTE = 5;
        static final int TIME_OUT_ERROR = 6;
        static final int PARSE_ERROR = 7;

        @Override
        public void handleMessage(Message msg) {
            dialog.dismiss();
            switch (msg.what) {
                case ID_EXIST:
                    showToast("아이디가 존재합니다.");
                    break;
                case UPDATE_ID:
                    showToast("회원가입 되었습니다.");
                    break;
                case NO_ID:
//                    showToast("해당 아이디가 없습니다.");
                    break;
                case SUCCESS:
                    Intent intent = new Intent(SignUpActivity.this, MainActivity.class);
                    intent.putExtra("email", emailEditText.getText().toString());
                    startActivity(intent);
                    finish();
                    break;
                case FALSE_PW:
//                    showToast("아이디 암호가 다릅니다 다시 시도하세요");
                    break;
                case VALIDE_ROUTE:
                    showToast("VALIDE_ROUTE");
                    break;
                case TIME_OUT_ERROR :
                    showToast("TIME_OUT_ERROR");
                    break;
                case PARSE_ERROR:
                    showToast("PARSE_ERROR");
                    break;

            }
        }
    }
    void showToast(String text){
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
        emailEditText.setText("");
        passwordEditText.setText("");
    }
}
