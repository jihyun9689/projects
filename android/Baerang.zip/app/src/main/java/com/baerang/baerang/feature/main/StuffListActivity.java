package com.baerang.baerang.feature.main;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.baerang.baerang.R;
import com.baerang.baerang.database.DbOpenHelper;
import com.baerang.baerang.feature.main.infoStuff.InfoStuffActivity;
import com.baerang.baerang.feature.main.registerStuff.DeviceScanActivity;

import java.sql.SQLDataException;

public class StuffListActivity extends Activity{
    private static final String TAG = "StuffListActivity";
    ListAdapter listAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stufflist);

        ListView listView = (ListView)findViewById(R.id.listView);
        listAdapter = new ListAdapter(this);
        listView.setAdapter(listAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

                Intent intentInfo = new Intent(StuffListActivity.this, InfoStuffActivity.class);
                intentInfo.putExtra("index", position + 1);
                startActivity(intentInfo);
            }
        });

        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.register);
        linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(StuffListActivity.this, DeviceScanActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        listAdapter.notifyDataSetInvalidated();
    }

    class ListAdapter extends BaseAdapter{
        Context context;
        LayoutInflater inflater;

        public ListAdapter (Context context){
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            this.context = context;

        }

        @Override
        public int getCount() {
            DbOpenHelper dbOpenHelper = new DbOpenHelper(context);
            try {
                dbOpenHelper.open();
            } catch (SQLDataException e) {
                e.printStackTrace();
            }

            Log.e("aaaa", "getCount : " + dbOpenHelper.getTotalCount());
            return dbOpenHelper.getTotalCount();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {

            if(view == null) view = inflater.inflate(R.layout.listitem_stuff, viewGroup, false);

            DbOpenHelper dbOpenHelper = new DbOpenHelper(context);

            try {
                dbOpenHelper.open();
            } catch (SQLDataException e) {
                e.printStackTrace();
            }

            TextView text_name = (TextView) view.findViewById(R.id.text_name);
            text_name.setText(dbOpenHelper.readTable(i+1).getString(0));
            TextView text_distance = (TextView) view.findViewById(R.id.text_distance);
            text_distance.setText(dbOpenHelper.readTable(i+1).getString(1));

            Log.e("aaaa", "getView : " +i);

            return view;
        }


    }
}