package com.wowell.secretletter.feature.login.selectInfo;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

import com.wowell.secretletter.R;
import com.wowell.secretletter.base.BaseActivity;
import com.wowell.secretletter.controller.UserInfoController;
import com.wowell.secretletter.utils.logger.LogManager;
import com.wowell.secretletter.view.autoCompleteText.EditTextExtends;

/**
 * Created by kim on 2016-04-09.
 */
public class SelectInfoActivity extends BaseActivity {
    EditTextExtends autoCompleteTextView;
    ArrayAdapter<String> arrayAdapter;
    String[] strings = new String[]{
        "가톨릭대학교", "경희대학교", "서울대학교", "인하대학교"
    };

    Intent intent;
    String key;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_info);
        autoCompleteTextView = (EditTextExtends)findViewById(R.id.select_info_auto_complete_textview);

        init();
    }

     private void init(){
         intent = getIntent();
         key = intent.getStringExtra("key");
         LogManager.printLog(getClass(),"key : " + key);
         arrayAdapter = new ArrayAdapter<String>(
                 getApplicationContext(),
                 R.layout.item_auto_complete_textview,
                 strings
         );
         autoCompleteTextView.setAdapter(arrayAdapter);
         autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
             @Override
             public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                 String result = autoCompleteTextView.getText().toString();

                 if(key.equals("university")){
                     intent.putExtra("result", result);
                     autoCompleteTextView.finishSelectInfo();
                     setResult(InsertInfoActivity.UNIVERSITY_ACTIVITY_RESULT, intent);

                     //activity를 종료하기 전에 유니버시티를 저장하고 끝낸다.
                     UserInfoController.getMyInfo().setUniversity(result);

                     finish();
                 }else{
                     intent.putExtra("result", result);
                     autoCompleteTextView.finishSelectInfo();
                     setResult(InsertInfoActivity.MAJOR_ACTIVITY_RESULT, intent);

                     //activity를 종료하기 전에 메이저를 저장하고 끝낸다.
                     UserInfoController.getMyInfo().setMajor(result);

                     finish();
                 }
             }
         });
     }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}
