package com.wowell.secretletter.utils.cacheMemory;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Environment;
import android.text.TextUtils;

import com.wowell.secretletter.utils.logger.LogManager;

import java.io.File;
import java.io.FilenameFilter;
import java.util.Calendar;
import java.util.TreeSet;

/**
 * Created by kim on 2016-01-19.
 */
public class DiskLruImageCache {
    private static final String TAG = "DiskLruImageCache";
    //private static File mDiskCache;

    private static Bitmap.CompressFormat mCompressFormat = Bitmap.CompressFormat.JPEG;
    private static int mCompressQuality = 70;
    private static final int HTTP_CACHE_SIZE = 10 * 1024 * 1024;
    private static final int APP_VERSION = 1;
    private static final int VALUE_COUNT = 1;

    private static final String uniqueName = "talmemory";


    public static File getDiskCacheDir(Context context) {

        File mDiskCache;
        // Check if media is mounted or storage is built-in, if so, try and use external cache dir
        // otherwise use internal cache dir
        if (Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState()) || !isExternalStorageRemovable()) {

            String externalCachePath = getExternalCacheDir(context).getPath();
            if (TextUtils.isEmpty(uniqueName)) {
                mDiskCache = new File(externalCachePath);
            } else {
                mDiskCache = new File(externalCachePath + File.separator + uniqueName);
            }
            if (mDiskCache.mkdirs() || mDiskCache.isDirectory()) {
                return mDiskCache;
            }
        }

        String internalCachePath = context.getCacheDir().getPath();
        if (TextUtils.isEmpty(uniqueName)) {
            mDiskCache = new File(internalCachePath);
        } else {
            mDiskCache = new File(internalCachePath + File.separator + uniqueName);
        }

        mDiskCache.mkdirs();
        return mDiskCache;
    }

    public static File makeNewImageFile(Context context){
        Calendar calendar = Calendar.getInstance();
        return new File(DiskLruImageCache.getDiskCacheDir(context).getAbsolutePath()+File.separator+calendar.getTimeInMillis()+".jpg");
    }

    public static String getCacheImgFilePath(Context context, String imgFileName){
        return DiskLruImageCache.getDiskCacheDir(context).getAbsolutePath() + File.separator + imgFileName;
    }

    public static boolean deleteLastCacheFile(Context context){
        if(!getFileNameList(context).isEmpty()) {
            File file = new File(getCacheImgFilePath(context, getFileNameList(context).last()));
            if(file.exists()){
                file.delete();
                return true;
            }
        }
        return false;
    }

    public static String getLastCacheFileName(Context context){
        if(getFileNameList(context).isEmpty()){
            return null;
        }
        return getFileNameList(context).last();
    }

    public static TreeSet<String> getFileNameList(Context context){ //알아 보기 쉽게 메소드 부터 시작합니다.
        TreeSet<String> fileArrayList = new TreeSet<>();
        try{
            FilenameFilter fileFilter = new FilenameFilter(){  //이부분은 특정 확장자만 가지고 오고 싶을 경우 사용하시면 됩니다.
                public boolean accept(File dir, String name){
                    return name.endsWith("jpg") || name.endsWith("png");//이 부분에 사용하고 싶은 확장자를 넣으시면 됩니다.
                } //end accept
            };
            File file = new File(DiskLruImageCache.getDiskCacheDir(context).getAbsolutePath()); //경로를 SD카드로 잡은거고 그 안에 있는 A폴더 입니다. 입맛에 따라 바꾸세요.
            File[] files = file.listFiles(fileFilter);//위에 만들어 두신 필터를 넣으세요. 만약 필요치 않으시면 fileFilter를 지우세요.
            for(File eachFile : files){
                fileArrayList.add(eachFile.getName());//루프로 돌면서 어레이에 하나씩 집어 넣습니다.
                LogManager.printLog(DiskLruImageCache.class,eachFile.getName());
            }

        }catch( Exception e ){
            e.getStackTrace();

        }//end catch()
        return fileArrayList;
    }//end getTitleList




//    private static boolean writeBitmapToFile( Bitmap bitmap, DiskLruCache.Editor editor )
//            throws IOException, FileNotFoundException {
//        OutputStream out = null;
//        try {
//            out = new BufferedOutputStream( editor.newOutputStream( 0 ), Utils.IO_BUFFER_SIZE );
//            return bitmap.compress( mCompressFormat, mCompressQuality, out );
//        } finally {
//            if ( out != null ) {
//                out.close();
//            }
//        }
//    }

//    public static void put( String key, Bitmap data ) {
//
//        DiskLruCache.Editor editor = null;
//        try {
//            editor = mDiskCache.edit( key );
//            if ( editor == null ) {
//                return;
//            }
//
//            if( writeBitmapToFile( data, editor ) ) {
//                mDiskCache.flush();
//                editor.commit();
//            } else {
//                editor.abort();
//            }
//        } catch (IOException e) {
//            try {
//                if ( editor != null ) {
//                    editor.abort();
//                }
//            } catch (IOException ignored) {
//            }
//        }
//    }

//    public static Bitmap getBitmap( String key ) {
//
//        Bitmap bitmap = null;
//        DiskLruCache.Snapshot snapshot = null;
//        try {
//
//            snapshot = mDiskCache.get( key );
//            if ( snapshot == null ) {
//                return null;
//            }
//            final InputStream in = snapshot.getInputStream( 0 );
//            if ( in != null ) {
//                final BufferedInputStream buffIn =
//                        new BufferedInputStream( in, Utils.IO_BUFFER_SIZE );
//                bitmap = BitmapFactory.decodeStream(buffIn);
//            }
//        } catch ( IOException e ) {
//            e.printStackTrace();
//        } finally {
//            if ( snapshot != null ) {
//                snapshot.close();
//            }
//        }
//        return bitmap;
//    }

//    public static boolean containsKey( String key ) {
//
//        boolean contained = false;
//        DiskLruCache.Snapshot snapshot = null;
//        try {
//            snapshot = mDiskCache.get( key );
//            contained = snapshot != null;
//        } catch (IOException e) {
//            e.printStackTrace();
//        } finally {
//            if ( snapshot != null ) {
//                snapshot.close();
//            }
//        }
//
//        return contained;
//
//    }
//
//    public static void clearCache() {
//        try {
//            mDiskCache.delete();
//        } catch ( IOException e ) {
//            e.printStackTrace();
//        }
//    }



    @TargetApi(Build.VERSION_CODES.GINGERBREAD)
    public static boolean isExternalStorageRemovable() {
        if (Utils.hasGingerbread()) {
            return Environment.isExternalStorageRemovable();
        }
        return true;
    }

    @TargetApi(Build.VERSION_CODES.FROYO)
    public static File getExternalCacheDir(Context context) {
        if (Utils.hasFroyo()) {
            return context.getExternalCacheDir();
        }

        // Before Froyo we need to construct the external cache dir ourselves
        final String cacheDir = "/Android/data/" + context.getPackageName() + "/cache/";
        return new File(Environment.getExternalStorageDirectory().getPath() + cacheDir);
    }


}
