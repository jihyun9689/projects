package com.wowell.secretletter.utils.http;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.wowell.secretletter.utils.logger.LogManager;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

/**
 * Created by kim on 2016-01-11.
 */

public class RequestThread extends Thread {

    public static final int SUCCESS = 0;
    public static final int FAIL = 1;
    public static final int TIME_OUT_ERROR = 2;
    public static final int PARSE_ERROR = 3;

    List<NameValuePair> nameValue;
    String data = "";
    Handler handler;
    String lastUri;

    public RequestThread(String lastUri, List<NameValuePair> nameValue, Handler handler){
        this.nameValue = nameValue ;
        this.handler = handler;
        this.lastUri = lastUri;
    }

    public void run(){
        String url = ServerUtil.SERVER_URL + lastUri;
        LogManager.printLog(getClass(), url);

        HttpClient client = NetManager1.getHttpClient();
        HttpPost post = NetManager1.getPost(url);

        HttpResponse response = null;
        BufferedReader br = null;
        StringBuffer sb = null;

        String line = "";
        try{

            //한글 깨짐을 막기위해서 UTF-8로 설정해주어야한다.
            UrlEncodedFormEntity entity = new UrlEncodedFormEntity(nameValue,"UTF-8");
            post.setEntity(entity);

            response = client.execute(post);
            int code = response.getStatusLine().getStatusCode();
            LogManager.printLog(getClass(), "process code : " + code);
            switch(code){
                case 200 :
//                  br = new BufferedReader(new InputStreamReader(response.getEntity().getContent(),"euc-kr"));
                    br = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
                    sb = new StringBuffer();
                    while((line = br.readLine())!= null) {
                        sb.append(line);
                    }
                    data = sb.toString();

                    LogManager.printLog(getClass(),"data : " +data);

                    if(data.equals("success")){
                        handler.sendEmptyMessage(SUCCESS);
                    }else if(data.equals("fail")){
                        handler.sendEmptyMessage(FAIL);
                    }else {

                        Message msg = new Message();
                        Bundle bundle = new Bundle();
                        bundle.putString("data",data);
                        msg.setData(bundle);
                        handler.sendMessage(msg);
                    }
                    break;
                default :
                    handler.sendEmptyMessage(TIME_OUT_ERROR);
            }

        }catch(Exception e){
            LogManager.printError(getClass(), "login parser error : " + e);
            handler.sendEmptyMessage(PARSE_ERROR);
        }finally{
            try{
                br.close();
            }catch(Exception e){}

        }
    }


}

