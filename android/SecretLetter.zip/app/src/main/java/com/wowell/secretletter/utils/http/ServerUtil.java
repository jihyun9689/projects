package com.wowell.secretletter.utils.http;

public class ServerUtil {
	public static final String SERVER_URL = "http://192.168.0.3:3003/";
}
