package com.wowell.secretletter.utils.timer;

import android.os.Handler;
import android.os.Message;
import android.widget.TextView;

import java.util.Calendar;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by kim on 2016-04-19.
 */
public class TimeCounter {
    TimeHandler timeHandler;
    Timer timer;
    TimerTask timerTask;

    public TimeCounter(TextView timeTextView, long startTimeLong) {

        timeHandler = new TimeHandler(startTimeLong, timeTextView);

        timer = new Timer();
        timerTask = new TimerTask() {
            @Override
            public void run() {
                timeHandler.sendEmptyMessage(0);
            }
        };
    }

    private class TimeHandler extends Handler {
        long starTime;
        TextView timeTextView;

        public TimeHandler(long starTime, TextView timeTextView){
            this.starTime = starTime;
            this.timeTextView = timeTextView;
        }

        @Override
        public void handleMessage(Message msg) {
            if(msg.what == 0){
                Calendar calendar = Calendar.getInstance();
                long second = (calendar.getTimeInMillis() - starTime) / 1000;
                long secondTime = second % 60;
                long minuteTime = (second / 60) % 60;
                long hourTime = (second / 60 / 60) % 60;

                timeTextView.setText(String.format("%02d : %02d : %02d ",hourTime, minuteTime, secondTime));
            }
        }
    }

    public void startCount(){
        timer.schedule(timerTask, 0, 1000);
    }
    public void stopCount(){
        timer.cancel();
    }

}
