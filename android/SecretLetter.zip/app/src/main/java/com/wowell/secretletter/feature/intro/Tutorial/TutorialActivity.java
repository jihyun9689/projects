package com.wowell.secretletter.feature.intro.Tutorial;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.wowell.secretletter.R;
import com.wowell.secretletter.base.BaseActivity;
import com.wowell.secretletter.base.state.MappingState;
import com.wowell.secretletter.base.state.State;
import com.wowell.secretletter.base.state.TutorialState;
import com.wowell.secretletter.feature.main.MainActivity;

/**
 * Created by kim on 2016-04-11.
 */
public class TutorialActivity extends BaseActivity {
    Button nextBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TutorialState tutorialState = TutorialState.getInstance();
        if(!tutorialState.getValue()){
            //튜토리얼이 필요할 때
            setContentView(R.layout.activity_tutorial);

            nextBtn = (Button)findViewById(R.id.tutorial_next_btn);
            init();
        }else{
            //튜토리얼이 필요 없을 때
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
            finish();
        }
    }

    private void init(){
        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);

                State state = MappingState.getState(TutorialState.TUTORIAL_STATE);
                state.setValue(TutorialState.NOT_NEED_TUTORIAL);
                finish();
            }
        });
    }
}
