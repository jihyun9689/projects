package com.wowell.secretletter.feature.main.problem.answerTabs;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.wowell.secretletter.R;
import com.wowell.secretletter.base.BaseFragment;
import com.wowell.secretletter.controller.ProblemController;
import com.wowell.secretletter.controller.UserInfoController;
import com.wowell.secretletter.feature.main.result.ResultActivity;
import com.wowell.secretletter.feature.main.problem.ProblemActivity;
import com.wowell.secretletter.model.Problem;
import com.wowell.secretletter.utils.http.LoadImageFromURL;
import com.wowell.secretletter.utils.http.RequestThread;
import com.wowell.secretletter.utils.logger.LogManager;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kim on 2016-04-14.
 */
public class AnswerSheetFragment extends BaseFragment {
    Button replyBtn;
    ImageView[] answerImageView = new ImageView[4];
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragment_answer_sheet, container, false);
        replyBtn = (Button) view.findViewById(R.id.answer_sheet_reply_btn);
        answerImageView[0] = (ImageView) view.findViewById(R.id.answer_sheet_imageview1);
        answerImageView[1] = (ImageView) view.findViewById(R.id.answer_sheet_imageview2);
        answerImageView[2] = (ImageView) view.findViewById(R.id.answer_sheet_imageview3);
        answerImageView[3] = (ImageView) view.findViewById(R.id.answer_sheet_imageview4);

        init();
        return view;
    }

    @Override
    protected void init() {
        replyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), ResultActivity.class);
                startActivity(intent);
                ProblemController.deleteMessage(getActivity());
                ((ProblemActivity) getActivity()).finish();
            }
        });

        for(int i = 0 ; i < answerImageView.length ; i ++){
            if(ProblemController.getProblemGCM() != null){
                LoadImageFromURL.loadBitmap(ProblemController.getProblemGCM().getProblem() + "/answer" + (i + 1) + ".png", answerImageView[i]);
                //배열은 0부터 시작하므로 +1
                final int answer = i + 1;
                answerImageView[i].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        registerMyRecord(String.valueOf(answer));
                    }
                });
            }
        }
    }

    private void registerMyRecord(String answer){
        LogManager.printLog(getClass(),"getUserId : " + UserInfoController.getMyInfo().getUserId() + " ProblemController.getMessage() : " + ProblemController.getProblemGCM().getProblem());
        LogManager.printLog(getClass(),"answer : " + answer);
        List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        nameValuePairs.add(new BasicNameValuePair("action", "insert"));
        nameValuePairs.add(new BasicNameValuePair("user_id", UserInfoController.getMyInfo().getUserId()));
        nameValuePairs.add(new BasicNameValuePair("problem", ProblemController.getProblemGCM().getProblem()));
        nameValuePairs.add(new BasicNameValuePair("answer", answer));
        RequestThread requestThread = new RequestThread("solvedProblem.do", nameValuePairs, new RegisterRecordHandler());
        requestThread.start();
    }

    private class RegisterRecordHandler extends Handler{
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case RequestThread.SUCCESS:
                    Intent intent = new Intent(getActivity(), ResultActivity.class);
                    startActivity(intent);
                    ProblemController.deleteMessage(getActivity());
                    ((ProblemActivity) getActivity()).finish();
                    break;
                case RequestThread.FAIL:
                    Toast.makeText(getActivity(),"다시 시도해 주세요",Toast.LENGTH_SHORT).show();
                    break;

            }
        }
    }
}
