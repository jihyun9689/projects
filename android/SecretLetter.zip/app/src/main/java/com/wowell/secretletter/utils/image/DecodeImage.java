package com.wowell.secretletter.utils.image;

import android.Manifest;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.util.Log;

import com.wowell.secretletter.utils.logger.LogManager;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;

public class DecodeImage {
	final static String TAG = "DecodeImage";

	private static final int REQUEST_EXTERNAL_STORAGE = 1;

	public static Bitmap getResultBitmapUri(Context context, Uri uri, int reqWidth, int reqHeight ){
		String filePath = getPathFromUri(uri, context);
		LogManager.printLog(DecodeImage.class,"filePath1: " + filePath);
		Bitmap bitmap = decodeSampledBitmapFromResource(filePath, reqWidth, reqHeight);
		if(bitmap == null){
			LogManager.printLog(DecodeImage.class,"decodeSampledBitmapFromResource is null");
		}
		return getRotatedBitmap(bitmap, GetExifOrientation(filePath));
	}

	public static Bitmap getResultBitmapFilePath(Context context, String filePath, int reqWidth, int reqHeight ){
		LogManager.printLog(DecodeImage.class,"filePath2 : " + filePath);
		return getRotatedBitmap(decodeSampledBitmapFromResource(filePath, reqWidth, reqHeight), GetExifOrientation(filePath));
	}

	public static Bitmap decodeSampledBitmapFromResource(String filePath,
	        int reqWidth, int reqHeight) {

	    // First decode with inJustDecodeBounds=true to check dimensions


	    final BitmapFactory.Options options = new BitmapFactory.Options();
	    options.inJustDecodeBounds = true;
		BitmapFactory.decodeFile(filePath);
	    // Calculate inSampleSize
	    options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);

	    // Decode bitmap with inSampleSize set
	    options.inJustDecodeBounds = false;

	    return BitmapFactory.decodeFile(filePath, options);
	}
	
	private static int calculateInSampleSize(
            BitmapFactory.Options options, int reqWidth, int reqHeight) {
    // Raw height and width of image
    final int height = options.outHeight;
    final int width = options.outWidth;
    int inSampleSize = 1;

    if (height > reqHeight || width > reqWidth) {

        final int halfHeight = height / 2;
        final int halfWidth = width / 2;

        // Calculate the largest inSampleSize value that is a power of 2 and keeps both
        // height and width larger than the requested height and width.
        while ((halfHeight / inSampleSize) > reqHeight
                && (halfWidth / inSampleSize) > reqWidth) {
            inSampleSize *= 2;
        	}
    	}
    	return inSampleSize;
	}

	public static Bitmap getRotatedBitmap(Bitmap bitmap, int degrees){

		Bitmap b2;
		if(bitmap !=null){
			Matrix m = new Matrix();
			LogManager.printLog(DecodeImage.class,"bitmap.getWidth() : " + bitmap.getWidth() + "   bitmap.getHeight() " + bitmap.getHeight());
			m.setRotate(degrees, (float) bitmap.getWidth() / 2 , (float) bitmap.getHeight() / 2);
			try{
				if(bitmap.getHeight() > bitmap.getWidth()){
					b2 = Bitmap.createBitmap(bitmap,0 ,(bitmap.getHeight() - bitmap.getWidth()) / 2,bitmap.getWidth() ,bitmap.getWidth(),m,false);
				}else{
					b2 = Bitmap.createBitmap(bitmap, (bitmap.getWidth() - bitmap.getHeight()) / 2, 0, bitmap.getHeight(),bitmap.getHeight(),m,false);
				}

				if(bitmap != b2){
					bitmap.recycle();
					bitmap = b2;
				}
				LogManager.printLog(DecodeImage.class,"getRotatedBitmap");
			}catch (OutOfMemoryError e){
				LogManager.printLog(DecodeImage.class, e.getStackTrace().toString());
			}
		}else {
			LogManager.printError(DecodeImage.class,"bitmap is null in getRotatedBitmap");
		}
		return bitmap;

	}

	public static int GetExifOrientation(String filepath){
		int degree = 0;
		ExifInterface exif = null;
		
		try{
			exif = new ExifInterface(filepath);
		}catch (IOException e){
			Log.e(TAG,"cannot read exif");
			e.printStackTrace();
		}
		
		if(exif != null){
			int orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION,  -1);
			
			if(orientation != -1){
				switch (orientation) {
				case ExifInterface.ORIENTATION_ROTATE_90:
					LogManager.printLog(DecodeImage.class,"ORIENTATION_ROTATE_90");
					degree = 90;
					break;
				case ExifInterface.ORIENTATION_ROTATE_180:
					LogManager.printLog(DecodeImage.class,"ORIENTATION_ROTATE_180");
					degree = 180;
					break;
				case ExifInterface.ORIENTATION_ROTATE_270:
					LogManager.printLog(DecodeImage.class,"ORIENTATION_ROTATE_270");
					degree = 270;
					break;
				}
			}else{
				LogManager.printLog(DecodeImage.class,"ORIENTATION_ROTATE_0");

			}
		}
		
		return degree;
	}

	private static String getPathFromUri(Uri uri, Context context){
		Cursor cursor = context.getContentResolver().query(uri, null, null, null, null );
		cursor.moveToNext();
		String path = cursor.getString(cursor.getColumnIndex("_data"));
		cursor.close();
		return path;
	}

	public static File saveBitmaptoJpeg(Bitmap bitmap, String name, Context context){
		OutputStream outStream = null;
		//String StorageDirectory = context.getFilesDir().toString();

		LogManager.printLog(DecodeImage.class,"name : " + name);
		String StorageDirectory = context.getFilesDir().toString();
		File dir = new File(StorageDirectory + "/pro");
		dir.mkdirs();
		File file = null;
		if(name.endsWith("jpg")){
			 file = new File(dir.getAbsolutePath() + File.separator+ name);
		}else{
			 file = new File(dir.getAbsolutePath() + File.separator+ name + ".jpg");
		}


		LogManager.printLog(DecodeImage.class, file.getAbsolutePath());
		try {
			outStream = new FileOutputStream(file);
			bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outStream);
			outStream.flush();
			outStream.close();
			return file;
		} catch (FileNotFoundException e) {
			LogManager.printLog(DecodeImage.class, e.getMessage());
		} catch (IOException e) {
			LogManager.printLog(DecodeImage.class, e.getMessage());
		}
		return null;
	}

	public static void getFileNameList(Context context){ //알아 보기 쉽게 메소드 부터 시작합니다.
		ArrayList<String> fileArrayList = new ArrayList<>();

		String storagePath = context.getFilesDir().toString();
		String foler_name = "/pro";
		String string_path = storagePath + foler_name;

		try{
			LogManager.printLog(DecodeImage.class,"~~~~~~~~~~~~~~~~~~~fileList~~~~~~~~~~~~~~~~~~~~~~~");
			FilenameFilter fileFilter = new FilenameFilter(){  //이부분은 특정 확장자만 가지고 오고 싶을 경우 사용하시면 됩니다.
				public boolean accept(File dir, String name){
					return name.endsWith("jpg") || name.endsWith("png");//이 부분에 사용하고 싶은 확장자를 넣으시면 됩니다.
				} //end accept
			};

			File file = new File(string_path); //경로를 SD카드로 잡은거고 그 안에 있는 A폴더 입니다. 입맛에 따라 바꾸세요.
			File[] files = file.listFiles(fileFilter);//위에 만들어 두신 필터를 넣으세요. 만약 필요치 않으시면 fileFilter를 지우세요.
			for(File eachFile : files){
				fileArrayList.add(eachFile.getAbsolutePath());//루프로 돌면서 어레이에 하나씩 집어 넣습니다.
				LogManager.printLog(DecodeImage.class,eachFile.getAbsolutePath());
			}
			LogManager.printLog(DecodeImage.class,"~~~~~~~~~~~~~~~~~~~fileList~~~~~~~~~~~~~~~~~~~~~~~");
		}catch( Exception e ){
			e.getStackTrace();

		}
	}//end getTitleList

//	public static String getProfileImageFilePath(String name, Context context){
//		String storagePath = context.getFilesDir().toString();
//		// Get Absolute Path in External Sdcard
//		String foler_name = "/pro/";
//		String file_name = name+".jpg";
//		String string_path = storagePath + foler_name;
//		return string_path+file_name;
//	}

	
}

