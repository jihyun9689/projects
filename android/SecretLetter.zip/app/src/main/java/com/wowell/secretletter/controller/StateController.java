package com.wowell.secretletter.controller;

import android.content.Context;

import com.wowell.secretletter.base.state.LoginState;
import com.wowell.secretletter.base.state.MappingState;
//import com.wowell.secretletter.base.state.ProblemState;
import com.wowell.secretletter.base.state.State;
import com.wowell.secretletter.base.state.TutorialState;
import com.wowell.secretletter.base.state.UserInfoState;
import com.wowell.secretletter.utils.save.ManageSharedPreference;

import java.util.HashMap;

/**
 * Created by kim on 2016-03-24.
 */
public class StateController {

    public static void saveState(Context context){

        ManageSharedPreference manageSharedPreference = new ManageSharedPreference(context);
        MappingState.getState(LoginState.LOGIN_STATE).save(manageSharedPreference);
        //MappingState.getState(ProblemState.PROBLEM_STATE).save(manageSharedPreference);
        MappingState.getState(UserInfoState.USER_INFO_STATE).save(manageSharedPreference);
        MappingState.getState(TutorialState.TUTORIAL_STATE).save(manageSharedPreference);
    }

    public static void settingState(Context context){

        ManageSharedPreference manageSharedPreference = new ManageSharedPreference(context);
        LoginState.getInstance().setting(manageSharedPreference);
        //ProblemState.getInstance().setting(manageSharedPreference);
        UserInfoState.getInstance().setting(manageSharedPreference);
        TutorialState.getInstance().setting(manageSharedPreference);
    }

    public static void initialzeState(Context context){
        ManageSharedPreference manageSharedPreference = new ManageSharedPreference(context);

        LoginState.getInstance().delete(manageSharedPreference);
        UserInfoState.getInstance().delete(manageSharedPreference);
        TutorialState.getInstance().delete(manageSharedPreference);
    }

}
