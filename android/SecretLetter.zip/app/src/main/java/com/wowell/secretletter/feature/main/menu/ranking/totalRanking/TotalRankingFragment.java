package com.wowell.secretletter.feature.main.menu.ranking.totalRanking;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.wowell.secretletter.R;
import com.wowell.secretletter.base.BaseFragment;
import com.wowell.secretletter.model.RankingList;
import com.wowell.secretletter.utils.http.RequestThread;
import com.wowell.secretletter.utils.json.JSONProductParser;
import com.wowell.secretletter.utils.logger.LogManager;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kim on 2016-04-04.
 */
public class TotalRankingFragment extends BaseFragment{
    ListView listView;
    TotalRankingAdapter totalRankingAdapter;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_total_ranking, container, false);

        listView = (ListView)view.findViewById(R.id.total_ranking_listview);


        init();
        return view;
    }

    @Override
    protected void init() {
        totalRankingAdapter = new TotalRankingAdapter(getActivity());
        LogManager.printLog(getClass(),"TotalRankingFragment ");
        getTotalRanking();
    }

    private void getTotalRanking(){
        List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        nameValuePairs.add(new BasicNameValuePair("action", "total_ranking")); //TODO register ID
        nameValuePairs.add(new BasicNameValuePair("problem", "2016_04_19"));
        RequestThread requestThread = new RequestThread("ranking.do", nameValuePairs, new TotalRankingRequestHandler());
        requestThread.start();
    }

    private class TotalRankingRequestHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            Bundle bundle = msg.getData();
            if(bundle != null){
                String data = bundle.getString("data");
                LogManager.printLog(getClass(), "TotalRankingRequestHandler data : " + data);
                ArrayList<RankingList> rankingLists = JSONProductParser.parser(data);

                totalRankingAdapter.setItems(rankingLists);
                listView.setAdapter(totalRankingAdapter);
            }

            switch (msg.what){
                case RequestThread.SUCCESS:
                    break;
                case RequestThread.FAIL:
                    break;

            }
        }
    }
}
