package com.wowell.secretletter.feature.main.tabs.todayLetter;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.wowell.secretletter.R;
import com.wowell.secretletter.base.BaseFragment;
import com.wowell.secretletter.controller.ProblemController;
import com.wowell.secretletter.feature.main.GcmListener;
import com.wowell.secretletter.feature.main.problem.ProblemActivity;
import com.wowell.secretletter.utils.http.RequestThread;
import com.wowell.secretletter.utils.logger.LogManager;
import com.wowell.secretletter.utils.timer.TimeCounter;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kim on 2016-04-12.
 */
public class TodayLetterFragment extends BaseFragment implements GcmListener{
    TextView timeTextView;
    Button openLetterBtn;
    TimeCounter timeCounter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_today_letter, container, false);

        timeTextView = (TextView)view.findViewById(R.id.today_letter_time_textview);
        openLetterBtn =(Button)view.findViewById(R.id.today_letter_open_btn);
        init();
        return view;
    }

    @Override
    protected void init() {
        if(ProblemController.getProblemGCM() != null){
            startTimer(true);
        }else{
            startTimer(false);
        }


        openLetterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timeCounter.stopCount();

                Intent intent = new Intent(getActivity(), ProblemActivity.class);
                startActivity(intent);
                getMainActivity().finish();
                //TODO 액티비티를 종료시키냐 ?
            }
        });
    }

    @Override
    public void messageHandler(String message) {
        if(message.equals("receive")){
            //gcm 메세지를 받았을때
            LogManager.printLog(getClass(), "messageHandler");
            startTimer(true);
        }
    }

    private void startTimer(boolean enable){
        if(enable){
            timeTextView.setVisibility(View.VISIBLE);
            openLetterBtn.setVisibility(View.VISIBLE);
            timeCounter = new TimeCounter(timeTextView, ProblemController.getProblemGCM().getStartTimeLong());
            timeCounter.startCount();
        }else{
            timeTextView.setVisibility(View.INVISIBLE);
            openLetterBtn.setVisibility(View.INVISIBLE);
        }
    }
}
