package com.wowell.secretletter.base.state;

import java.util.HashMap;

/**
 * Created by kim on 2016-03-24.
 */
public class MappingState {

    private static HashMap<String, State> stateHashMap = new HashMap<String, State>();

    public static HashMap<String, State> getMapState(){
        return stateHashMap;
    }

    public static State getState(String stateKey){
        return stateHashMap.get(stateKey);
    }

    public static void setState(String stateKey, State state){
        stateHashMap.put(stateKey, state);
    }

}
