package com.wowell.secretletter.feature.main.problem;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.wowell.secretletter.R;
import com.wowell.secretletter.base.BaseActivity;
//import com.wowell.secretletter.base.state.ProblemState;
import com.wowell.secretletter.controller.ProblemController;
import com.wowell.secretletter.controller.UserInfoController;
import com.wowell.secretletter.utils.http.LoadImageFromURL;
import com.wowell.secretletter.feature.main.result.ResultActivity;
import com.wowell.secretletter.feature.main.problem.answerTabs.AnswerSheetFragment;
import com.wowell.secretletter.feature.main.problem.answerTabs.MemoSheetFragment;
import com.wowell.secretletter.feature.main.problem.answerTabs.ProblemSheetFragment;
import com.wowell.secretletter.utils.http.RequestThread;
import com.wowell.secretletter.utils.logger.LogManager;
import com.wowell.secretletter.utils.timer.TimeCounter;
import com.wowell.secretletter.view.answerSheet.AnswerSheet;
import com.wowell.secretletter.view.answerSheet.AnswerSheetType;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by kim on 2016-03-22.
 */
public class ProblemActivity extends BaseActivity{

    ImageView problemImageView, hintBtn;

    TextView timeTextView;
    Button answerBtn;
    ViewPager viewPager;
    LinearLayout memoLinearLayout;
    TimeCounter timeCounter;
    static int prePosition = 1;

    int pixel = 0;
    boolean pagerRightScrollFlag = false;

    private static int btnState = 0;
    int width = 0;
    BroadcastReceiver broadcastReceiver;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_problem);

        problemImageView = (ImageView)findViewById(R.id.problem_problem_imageview);
        hintBtn = (ImageView)findViewById(R.id.problem_hint_imageview);
        timeTextView = (TextView)findViewById(R.id.problem_time_textview);
        viewPager = (ViewPager)findViewById(R.id.problem_viewpager);
        memoLinearLayout = (LinearLayout)findViewById(R.id.problem_memo_linearlayout);

        init();
    }

    private void init() {
        loadProblemImage();

        ViewPagerAdapter viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        viewPager.setAdapter(viewPagerAdapter);
        viewPager.setCurrentItem(1);

        pixel = dpToPx(getApplicationContext(), 10);
        LogManager.printLog(getClass(),"pixel : " + pixel);

        DisplayMetrics dm = getApplicationContext().getResources().getDisplayMetrics();
        width = dm.widthPixels;
        if(ProblemController.getProblemGCM() != null){
            timeCounter = new TimeCounter(timeTextView, ProblemController.getProblemGCM().getStartTimeLong());
            timeCounter.startCount();
        }
        viewPager.setOffscreenPageLimit(2);
        viewPager.addOnPageChangeListener(simpleOnPageChangeListener);
    }

    @Override
    public void onResume() {
        super.onResume();
        IntentFilter filter = new IntentFilter("GcmListener");
        registerReceiver(broadcastReceiver, filter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(broadcastReceiver != null){
            unregisterReceiver(broadcastReceiver);
        }
        timeCounter.stopCount();
    }

    ViewPager.SimpleOnPageChangeListener simpleOnPageChangeListener =
            new ViewPager.SimpleOnPageChangeListener(){
                @Override
                public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                    super.onPageScrolled(position, positionOffset, positionOffsetPixels);
                }

                @Override
                public void onPageSelected(int position) {

                    if (position == 0) {
                        attachMemoPager(true);
                    } else if (prePosition == 0 && position == 1) {
                        attachMemoPager(false);
                    }
                    prePosition = position;
                    super.onPageSelected(position);
                }

                @Override
                public void onPageScrollStateChanged(int state) {
                    LogManager.printLog(getClass(), "state : " + state);

                    super.onPageScrollStateChanged(state);
                }
            };

    private void attachMemoPager(boolean enable){
        if(enable){
            memoLinearLayout.setVisibility(View.VISIBLE);
            TranslateAnimation translateAnimation = new TranslateAnimation(
                    Animation.RELATIVE_TO_PARENT, 0,
                    Animation.RELATIVE_TO_PARENT, 0,
                    Animation.RELATIVE_TO_PARENT, 1,
                    Animation.RELATIVE_TO_PARENT, 0);
            translateAnimation.setDuration(500);
            translateAnimation.setFillAfter(true);
            memoLinearLayout.startAnimation(translateAnimation);
        }else {
            TranslateAnimation translateAnimation = new TranslateAnimation(
                    Animation.RELATIVE_TO_PARENT, 0,
                    Animation.RELATIVE_TO_PARENT, 0,
                    Animation.RELATIVE_TO_PARENT, 0,
                    Animation.RELATIVE_TO_PARENT, 1);
            translateAnimation.setDuration(500);
            translateAnimation.setFillAfter(true);
            memoLinearLayout.startAnimation(translateAnimation);
            translateAnimation.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {}

                @Override
                public void onAnimationEnd(Animation animation) {
                    memoLinearLayout.setVisibility(View.GONE);
                }

                @Override
                public void onAnimationRepeat(Animation animation) {}
            });
        }

    }

    private class ViewPagerAdapter extends FragmentStatePagerAdapter {

        public ViewPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            Fragment fragment = null;

            if(position == 0){
                fragment = new MemoSheetFragment();
            }else if(position == 1){
                fragment = new ProblemSheetFragment();
            }else if(position == 2){
                fragment = new AnswerSheetFragment();
            }
            return fragment;
        }

        @Override
        public int getCount() {
            return 3;
        }
    }

    private void loadProblemImage(){
        LogManager.printLog(getClass(), "GcmController.getMessage() : " + ProblemController.getProblemGCM().getProblem());
        if(ProblemController.getProblemGCM().getProblem() != null){
            String key = ProblemController.getProblemGCM().getProblem() + File.separator + "problem.png";
            LoadImageFromURL.loadBitmap(key, problemImageView);
        }
    }

//    View.OnClickListener onClickListener = new View.OnClickListener() {
//        @Override
//        public void onClick(View v) {
//        if(btnState == 0 && ProblemController.getProblemGCM().getProblem() != null){
//            selectAnswerSheetType(AnswerSheetType.MULTIPLE_CHOICE);
//            answerBtn.setText("정답 제출하기");
//        }else if(btnState == 1){
//            answerRequest();
//        }
//        btnState ++ ;
//        }
//    };
//
//    private void answerRequest(){
//        if(ProblemController.getProblemGCM().getProblem() != null){
//            List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
//            nameValuePairs.add(new BasicNameValuePair("action", "insert")); //TODO register ID
//            nameValuePairs.add(new BasicNameValuePair("user_id", UserInfoController.getMyInfo().getUserId()));
//            nameValuePairs.add(new BasicNameValuePair("problem", ProblemController.getProblemGCM().getProblem()));
//            RequestThread requestThread = new RequestThread("solvedProblem.do", nameValuePairs, new AnswerRequestHandler());
//            requestThread.start();
//        }
//    }
//
//    private class AnswerRequestHandler extends Handler{
//        @Override
//        public void handleMessage(Message msg) {
//            switch (msg.what){
//                case RequestThread.SUCCESS:
//                    ResultActivity resultFragment = new ResultActivity();
//                    //getMainActivity().replaceFragment(resultFragment, true);
//                    //TODO 답을 보내고 나서 상태 변화
//                    break;
//                case RequestThread.FAIL:
//
//                    //Toast.makeText(getActivity(),"다시 시도해주세요!",Toast.LENGTH_SHORT).show();
//                    btnState = 1;
//                    break;
//
//            }
//        }
//    }
//
//    private void selectAnswerSheetType(int answerSheetType){
//        AnswerSheet answerSheet;
//
//        switch (answerSheetType){
//            case AnswerSheetType.SHORT_ANSWER:
//
//                //answerSheet = new ShortAnswerQuestionLayout(getActivity());
//                //answerSheetLayout.addView(answerSheet);
//
//                break;
//
//            case AnswerSheetType.MULTIPLE_CHOICE:
//
//                //answerSheet = new MultipleChoiceLayout(getActivity(), GcmController.getMessage());
//                //answerSheetLayout.addView(answerSheet);
//
//                break;
//        }
//    }
//
//    private void updateTimeOnEachSecond() {
//        Timer timer = new Timer();
//        timer.schedule(new TimerTask() {
//            int hrs, min, sec;
//            Handler handler = new Handler(){
//                @Override
//                public void handleMessage(Message msg) {
//                    problemImageView.setVisibility(View.GONE);
//                    timeTextView.setVisibility(View.VISIBLE);
//                    timeTextView.setText(hrs + ":" + min +":" + sec);
//                }
//            };
//
//            @Override
//            public void run() {
//                Calendar calendar = Calendar.getInstance();
//                hrs = calendar.get(Calendar.HOUR_OF_DAY);
//                min = calendar.get(Calendar.MINUTE);
//                sec = calendar.get(Calendar.SECOND);
//                handler.sendEmptyMessage(0);
//            }
//        }, 0, 1000);
//    }

    public static int dpToPx(Context context, int dp) {
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        int px = Math.round(dp * (displayMetrics.xdpi / DisplayMetrics.DENSITY_DEFAULT));
        return px;
    }

    public static int pxToDp(Context context, int px) {
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        int dp = Math.round(px / (displayMetrics.xdpi / DisplayMetrics.DENSITY_DEFAULT));
        return dp;
    }
}
