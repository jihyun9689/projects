package com.wowell.secretletter.controller;

import android.content.Context;

import com.wowell.secretletter.model.gcm.ProblemGCM;
import com.wowell.secretletter.utils.json.JSONProductParser;
import com.wowell.secretletter.utils.save.ManageSharedPreference;

/**
 * Created by kim on 2016-04-07.
 */
public class ProblemController {
    //액티비티가 실행 중인지 확인하여 popupwindow를 띄울 것인지 결정
    private static boolean activityFlag = false;

    // GCM 메세지를 저장해 놓는다.
    private static String jsonMessage;
    private static ProblemGCM problemGCM;

    public static boolean isActivityFlag() {
        return activityFlag;
    }

    public static void setActivityFlag(boolean activityFlag) {
        ProblemController.activityFlag = activityFlag;
    }

    public static String getJsonMessage() {
        return jsonMessage;
    }

    public static void setJsonMessage(String jsonMessage) {
        ProblemController.jsonMessage = jsonMessage;
    }

    public static ProblemGCM getProblemGCM() {
        return problemGCM;
    }

    public static void setProblemGCM(ProblemGCM problemGCM) {
        ProblemController.problemGCM = problemGCM;
    }

    public static void saveMessage(Context context){
        ManageSharedPreference manageSharedPreference = new ManageSharedPreference(context);
        manageSharedPreference.putValue("jsonMessage", jsonMessage , String.class);
    }

    public static void settingMessage(Context context){
        ManageSharedPreference manageSharedPreference = new ManageSharedPreference(context);
        jsonMessage = manageSharedPreference.getValue("jsonMessage", null, String.class);
        if(jsonMessage != null) {
            problemGCM = JSONProductParser.problemGcmParser(jsonMessage);
        }
    }

    public static void deleteMessage(Context context){
        ManageSharedPreference manageSharedPreference = new ManageSharedPreference(context);
        manageSharedPreference.deleteValue("jsonMessage");
        jsonMessage = null;
        problemGCM = null;
    }
}
