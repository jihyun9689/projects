package com.wowell.secretletter.base.state;

import com.wowell.secretletter.utils.logger.LogManager;
import com.wowell.secretletter.utils.save.ManageSharedPreference;

/**
 * Created by kim on 2016-04-11.
 */
public class TutorialState implements State<Boolean> {
    // false 일때 튜토리얼을 봐야하는 상태
    // true 일때 필요 없음
    public static final String TUTORIAL_STATE = "tutorial";

    private boolean value = false;

    private static TutorialState tutorialState = null;

    public static boolean NEED_TUTORIAL = false;
    public static boolean NOT_NEED_TUTORIAL = true;

    private TutorialState() {
    }

    public static TutorialState getInstance(){
        if(tutorialState == null){
            tutorialState = new TutorialState();
        }
        return tutorialState;
    }

    @Override
    public void setValue(Boolean value) {
        this.value = value;
    }

    @Override
    public Boolean getValue() {
        return value;
    }

    @Override
    public String getStateName() {
        return TUTORIAL_STATE;
    }

    @Override
    public void save(ManageSharedPreference manageSharedPreference) {
        manageSharedPreference.putValue(TUTORIAL_STATE, value, Boolean.class);
    }

    @Override
    public void setting(ManageSharedPreference manageSharedPreference) {
        value = manageSharedPreference.getValue(TUTORIAL_STATE, NEED_TUTORIAL, Boolean.class);
        MappingState.setState(TUTORIAL_STATE, tutorialState);
    }

    @Override
    public void delete(ManageSharedPreference manageSharedPreference) {
        manageSharedPreference.deleteValue(TutorialState.TUTORIAL_STATE);
        value = false;
    }
}
