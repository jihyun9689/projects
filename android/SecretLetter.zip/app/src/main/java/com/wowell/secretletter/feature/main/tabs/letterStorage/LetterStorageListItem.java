package com.wowell.secretletter.feature.main.tabs.letterStorage;

/**
 * Created by kim on 2016-04-12.
 */
public class LetterStorageListItem {
    String title;
    String timeString;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTimeString() {
        return timeString;
    }

    public void setTimeString(String timeString) {
        this.timeString = timeString;
    }
}
