package com.wowell.secretletter.feature.main.menu.ranking.totalRanking;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.wowell.secretletter.R;
import com.wowell.secretletter.model.RankingList;

import java.util.ArrayList;

/**
 * Created by kim on 2016-04-04.
 */
public class TotalRankingAdapter extends BaseAdapter {
    Context context;
    ViewHolder viewHolder;
    LayoutInflater inflater;
    ArrayList<RankingList> items = new ArrayList<>();

    public TotalRankingAdapter(Context context) {
        inflater = LayoutInflater.from(context);
        this.context = context;
    }

    public void setItems(ArrayList<RankingList> items){
        this.items = items;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;

        if(convertView == null){
            viewHolder =  new ViewHolder();

            v = inflater.inflate(R.layout.item_total_ranking, null);

            viewHolder.numberTextView = (TextView)v.findViewById(R.id.total_ranking_number_textview);
            viewHolder.problemTextView = (TextView)v.findViewById(R.id.total_ranking_problem_textview);
            viewHolder.nicknameTextView = (TextView)v.findViewById(R.id.total_ranking_nickname_textview);
            viewHolder.timeLongTextView = (TextView)v.findViewById(R.id.total_ranking_timeLong_textview);

            v.setTag(viewHolder);
        }else {
            viewHolder= (ViewHolder)v.getTag();
        }


        if(viewHolder !=null){
            viewHolder.numberTextView.setText(String.valueOf(position));
            viewHolder.problemTextView.setText(items.get(position).getProblem());
            viewHolder.nicknameTextView.setText(items.get(position).getNickname());
            int time = (int) items.get(position).getTimeLong();
            int second = (time / 1000) % 60;
            int min = (time / 1000 / 60) % 60;
            int hour = (time / 1000 / 60 / 60) % 60;
            viewHolder.timeLongTextView.setText(String.format("%02d:%02d:%02d", hour, min, second));
        }
        return v;
    }

    class ViewHolder{
        public TextView numberTextView = null;
        public TextView problemTextView = null;
        public TextView nicknameTextView = null;
        public TextView timeLongTextView = null;
    }
}
