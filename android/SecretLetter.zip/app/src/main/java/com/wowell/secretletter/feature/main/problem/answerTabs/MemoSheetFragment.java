package com.wowell.secretletter.feature.main.problem.answerTabs;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.wowell.secretletter.R;
import com.wowell.secretletter.base.BaseFragment;

/**
 * Created by kim on 2016-04-14.
 */
public class MemoSheetFragment extends BaseFragment {


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragment_memo_sheet, container, false);


        return view;
    }

    @Override
    protected void init() {

    }


}
