package com.wowell.secretletter.feature.intro.Loading;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;

import com.wowell.secretletter.R;
import com.wowell.secretletter.base.BaseActivity;
import com.wowell.secretletter.feature.intro.Tutorial.TutorialActivity;
import com.wowell.secretletter.feature.main.MainActivity;

/**
 * Created by kim on 2016-04-09.
 */
public class LoadingActivity extends BaseActivity {
    ImageView circleImageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loading);

        circleImageView = (ImageView)findViewById(R.id.loading_circle_imageview);
        RotateAnimation rotateAnimation = new RotateAnimation(0, 360, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        rotateAnimation.setDuration(500);
        rotateAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                Intent intent = new Intent(getApplicationContext(), TutorialActivity.class);
                startActivity(intent);
                finish();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        circleImageView.setAnimation(rotateAnimation);
    }
}
