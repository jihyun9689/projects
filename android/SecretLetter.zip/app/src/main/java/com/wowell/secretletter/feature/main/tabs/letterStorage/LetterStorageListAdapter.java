package com.wowell.secretletter.feature.main.tabs.letterStorage;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.wowell.secretletter.R;
import com.wowell.secretletter.model.ProblemTable;
import com.wowell.secretletter.model.RankingList;
import com.wowell.secretletter.utils.logger.LogManager;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by kim on 2016-04-12.
 */
public class LetterStorageListAdapter extends BaseAdapter {

    Context context;
    ViewHolder viewHolder;
    LayoutInflater inflater;
    ArrayList<ProblemTable> problemTables;

    public LetterStorageListAdapter(Context context) {
        inflater = LayoutInflater.from(context);
        this.context = context;
    }

    public void setItem(ArrayList<ProblemTable> problemTables){
        this.problemTables = problemTables;
    }

    @Override
    public int getCount() {
        return problemTables.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;

        if(convertView == null){
            viewHolder =  new ViewHolder();

            v = inflater.inflate(R.layout.item_letter_stoage, null);

            viewHolder.titleTextView = (TextView)v.findViewById(R.id.letter_storage_title_textview);
            viewHolder.timeStringTextView = (TextView)v.findViewById(R.id.letter_storage_time_textview);

            v.setTag(viewHolder);
        }else {
            viewHolder= (ViewHolder)v.getTag();
        }


        if(viewHolder !=null){
            LogManager.printLog(getClass(),"problemTables.get(position).getProblem() : " + problemTables.get(position).getProblem());
            viewHolder.titleTextView.setText(problemTables.get(position).getProblem());

            Date date = new Date(problemTables.get(position).getStartTime());
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy.MM.dd / aa hh:mm");
            viewHolder.timeStringTextView.setText(simpleDateFormat.format(date));
        }
        return v;
    }

    class ViewHolder{
        public TextView titleTextView = null;
        public TextView timeStringTextView = null;
    }
}
