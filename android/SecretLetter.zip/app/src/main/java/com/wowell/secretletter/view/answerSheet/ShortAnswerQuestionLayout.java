package com.wowell.secretletter.view.answerSheet;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.wowell.secretletter.R;

/**
 * Created by kim on 2016-03-28.
 */
public class ShortAnswerQuestionLayout extends AnswerSheet{
    Context context;
    EditText editText;
    public ShortAnswerQuestionLayout(Context context) {
        super(context);
        this.context = context;
        init();
    }

    public ShortAnswerQuestionLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    String getAnswer() {
        return editText.getText().toString();
    }

    private void init(){

        setOrientation(VERTICAL);
        setView(context);
    }

    private void setView(Context context){

        editText = new EditText(context);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        editText.setLayoutParams(layoutParams);
        editText.setBackgroundResource(R.drawable.edittext_round);
        addView(editText);
    }

}
