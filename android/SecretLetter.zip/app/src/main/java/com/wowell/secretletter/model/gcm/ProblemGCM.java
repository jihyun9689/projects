package com.wowell.secretletter.model.gcm;

import com.wowell.secretletter.model.gcm.GcmPackage;

import java.io.Serializable;

public class ProblemGCM extends GcmPackage implements Serializable{
	
	private static final long serialVersionUID = -2980543567775441100L;

	private String problem;
	private String problemText;
	private long startTimeLong;
	private String type;
	public String getProblem() {
		return problem;
	}
	public void setProblem(String problem) {
		this.problem = problem;
	}
	public String getProblemText() {
		return problemText;
	}
	public void setProblemText(String problemText) {
		this.problemText = problemText;
	}
	public long getStartTimeLong() {
		return startTimeLong;
	}
	public void setStartTimeLong(long startTimeLong) {
		this.startTimeLong = startTimeLong;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "ProblemGCM{" +
				"kind=" + kind + '\'' +
				", problem='" + problem + '\'' +
				", problemText='" + problemText + '\'' +
				", startTimeLong=" + startTimeLong +
				", type='" + type + '\'' +
				'}';
	}
}
