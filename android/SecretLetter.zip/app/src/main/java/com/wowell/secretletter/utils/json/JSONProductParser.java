package com.wowell.secretletter.utils.json;

import android.util.Log;

import com.wowell.secretletter.model.ProblemTable;
import com.wowell.secretletter.model.RankingList;
import com.wowell.secretletter.model.gcm.ProblemGCM;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class JSONProductParser {
	private static final String TAG = "MainActivity";

	public static ArrayList<RankingList> parser(String jsonStr){
		 ArrayList<RankingList> data = new ArrayList<RankingList>();
		JSONArray arr = null;
		JSONObject json = null;
		RankingList item = null;
		JSONObject temp = null;
		try{
			json = new JSONObject(jsonStr);
			arr = json.getJSONArray("pList");
			for(int i = 0; i < arr.length(); i++){
				item = new RankingList();
				temp = arr.getJSONObject(i);
				item.setProblem(temp.getString("problem"));
				item.setNickname(temp.getString("nickname"));
				item.setTimeLong(temp.getLong("timeLong"));
				data.add(item);
			}
		}catch(Exception e){
			Log.v(TAG, "json error : " + e);
		}
		return data;
	}

	public static ArrayList<ProblemTable> problemParser(String jsonStr){
		ArrayList<ProblemTable> data = new ArrayList<ProblemTable>();
		JSONArray arr = null;
		JSONObject json = null;
		ProblemTable item = null;
		JSONObject temp = null;
		try{
			json = new JSONObject(jsonStr);
			arr = json.getJSONArray("pList");
			for(int i = 0; i < arr.length(); i++){
				item = new ProblemTable();
				temp = arr.getJSONObject(i);
				item.setNum(temp.getInt("num"));
				item.setProblem(temp.getString("problem"));
				item.setState(temp.getString("state"));
				item.setAnswer(temp.getString("answer"));
				item.setStartTime(temp.getLong("startTime"));
				item.setType(temp.getString("type"));
				data.add(item);
			}
		}catch(Exception e){
			Log.v(TAG, "json error : " + e);
		}
		return data;
	}

	public static ProblemGCM problemGcmParser(String jsonStr){
		ProblemGCM problemGCM = null;
		try {
			JSONObject json = new JSONObject(jsonStr);
			problemGCM = new ProblemGCM();
			problemGCM.setKind(json.getString("kind"));
			problemGCM.setProblem(json.getString("problem"));
			problemGCM.setProblemText(json.getString("problemText"));
			problemGCM.setStartTimeLong(json.getLong("startTimeLong"));
			problemGCM.setType(json.getString("type"));

		} catch (JSONException e) {
			e.printStackTrace();
		}
		return problemGCM;
	}


}
