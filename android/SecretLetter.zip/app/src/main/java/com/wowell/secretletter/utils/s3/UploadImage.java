//package com.wowell.secretletter.utils.s3;
//
//import android.annotation.SuppressLint;
//import android.content.ContentUris;
//import android.content.Context;
//import android.database.Cursor;
//import android.net.Uri;
//import android.os.Build;
//import android.os.Environment;
//import android.provider.DocumentsContract;
//import android.provider.MediaStore;
//
//import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener;
//import com.amazonaws.mobileconnectors.s3.transferutility.TransferObserver;
//import com.wowell.talboro.util.logger.LogManager;
//
//import java.io.File;
//import java.net.URISyntaxException;
//import java.util.HashMap;
//
///**
// * Created by kim on 2016-01-18.
// */
//public class UploadImage extends S3Util{
//    private static final String TAG = "UploadImage";
//    public static final int UPLOAD_TALTAL = 0;
//    public static final int UPLOAD_PROFILE = 1;
//
//    public static TransferObserver beginUploadForTaltal(File imgFile, Context context, TransferListener transferListener) {
//
//        LogManager.printLog(TAG, "imgFile.getName() : " + imgFile.getName() + "   imgFile : " + imgFile.getAbsolutePath());
//
//        sTransferUtility = getTransferUtility(context);
//
//        TransferObserver observer = sTransferUtility.upload(Constants.BUCKET_NAME, "taltal/" + imgFile.getName(), imgFile);
//        HashMap<String, Object> map = new HashMap<String, Object>();
//        fillMap(map, observer, false);
//        observer.setTransferListener(transferListener);
//
//        return observer;
//    }
//
//    public static TransferObserver beginUploadForProfile(File imgFile, Context context, TransferListener transferListener) {
//
//
//        LogManager.printLog(TAG, "imgFile.getName() : " + imgFile.getName() + "   imgFile : " + imgFile.getAbsolutePath());
//
//        sTransferUtility = getTransferUtility(context);
//
//        TransferObserver observer = sTransferUtility.upload(Constants.BUCKET_NAME, "profile/" + imgFile.getName(), imgFile);
//        HashMap<String, Object> map = new HashMap<String, Object>();
//        fillMap(map, observer, false);
//        observer.setTransferListener(transferListener);
//
//        return observer;
//    }
//
//    @SuppressLint("NewApi")
//    private static String getPath(Uri uri, Context context) throws URISyntaxException {
//        final boolean needToCheckUri = Build.VERSION.SDK_INT >= 19;
//        String selection = null;
//        String[] selectionArgs = null;
//        // Uri is different in versions after KITKAT (Android 4.4), we need to
//        // deal with different Uris.
//        if (needToCheckUri && DocumentsContract.isDocumentUri(context.getApplicationContext(), uri)) {
//            if (isExternalStorageDocument(uri)) {
//                final String docId = DocumentsContract.getDocumentId(uri);
//                final String[] split = docId.split(":");
//                return Environment.getExternalStorageDirectory() + "/" + split[1];
//            } else if (isDownloadsDocument(uri)) {
//                final String id = DocumentsContract.getDocumentId(uri);
//                uri = ContentUris.withAppendedId(
//                        Uri.parse("content://downloads/public_downloads"), Long.valueOf(id));
//            } else if (isMediaDocument(uri)) {
//                final String docId = DocumentsContract.getDocumentId(uri);
//                final String[] split = docId.split(":");
//                final String type = split[0];
//                if ("image".equals(type)) {
//                    uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
//                } else if ("video".equals(type)) {
//                    uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
//                } else if ("audio".equals(type)) {
//                    uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
//                }
//                selection = "_id=?";
//                selectionArgs = new String[] {
//                        split[1]
//                };
//            }
//        }
//        if ("content".equalsIgnoreCase(uri.getScheme())) {
//            String[] projection = {
//                    MediaStore.Images.Media.DATA
//            };
//            Cursor cursor = null;
//            try {
//                cursor = context.getContentResolver()
//                        .query(uri, projection, selection, selectionArgs, null);
//                int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
//                if (cursor.moveToFirst()) {
//                    return cursor.getString(column_index);
//                }
//            } catch (Exception e) {
//            }
//        } else if ("file".equalsIgnoreCase(uri.getScheme())) {
//            return uri.getPath();
//        }
//        return null;
//    }
//
//    /**
//     * @param uri The Uri to check.
//     * @return Whether the Uri authority is ExternalStorageProvider.
//     */
//    public static boolean isExternalStorageDocument(Uri uri) {
//        return "com.android.externalstorage.documents".equals(uri.getAuthority());
//    }
//
//    /**
//     * @param uri The Uri to check.
//     * @return Whether the Uri authority is DownloadsProvider.
//     */
//    public static boolean isDownloadsDocument(Uri uri) {
//        return "com.android.providers.downloads.documents".equals(uri.getAuthority());
//    }
//
//    /**
//     * @param uri The Uri to check.
//     * @return Whether the Uri authority is MediaProvider.
//     */
//    public static boolean isMediaDocument(Uri uri) {
//        return "com.android.providers.media.documents".equals(uri.getAuthority());
//    }
//}
//
