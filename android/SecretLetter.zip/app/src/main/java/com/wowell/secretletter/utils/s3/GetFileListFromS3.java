package com.wowell.secretletter.utils.s3;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Handler;

import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.wowell.secretletter.utils.logger.LogManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by kim on 2016-02-12.
 */
public class GetFileListFromS3 extends AsyncTask<Void, Void, Void> {
    static final String TAG = "GetFileListFromS3";

    private AmazonS3Client s3;
    private ArrayList<HashMap<String, Object>> transferRecordMaps;

    public static final int START_LOAD = 0;
    public static final int COMPLETED = 1;

    private List<S3ObjectSummary> s3ObjList;
    private ProgressDialog dialog;

    Context context;
    Handler handler;

    public GetFileListFromS3(Context context, Handler handler) {
        this.context = context;
        this.handler = handler;
        s3 = S3Util.getS3Client(context);
        transferRecordMaps = new ArrayList<HashMap<String, Object>>();
    }

    @Override
    protected void onPreExecute() {
        dialog = ProgressDialog.show(context,
                "Refreshing",
                "please_wait");
        handler.sendEmptyMessage(START_LOAD);
    }

    @Override
    protected Void doInBackground(Void... inputs) {
        // Queries files in the bucket from S3.

        s3ObjList = s3.listObjects(Constants.BUCKET_NAME).getObjectSummaries();
        transferRecordMaps.clear();
        for (S3ObjectSummary summary : s3ObjList) {
            HashMap<String, Object> map = new HashMap<String, Object>();
            LogManager.printLog(GetFileListFromS3.class, summary.getKey());

//            map.put("key", summary.getKey());
//            transferRecordMaps.add(map);

            if(summary.getKey().startsWith("taltal/") && summary.getKey().endsWith(".jpg")){
                map.put("key", summary.getKey());
                transferRecordMaps.add(map);
            }

        }
        return null;
    }

    @Override
    protected void onPostExecute(Void result) {
        handler.sendEmptyMessage(COMPLETED);
        dialog.dismiss();
    }

    public ArrayList<HashMap<String, Object>> getTransferRecordMaps() {
        return transferRecordMaps;
    }
}