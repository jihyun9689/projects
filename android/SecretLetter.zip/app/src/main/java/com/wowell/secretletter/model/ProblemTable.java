package com.wowell.secretletter.model;

import java.io.Serializable;

public class ProblemTable implements Serializable{

	private static final long serialVersionUID = 6126729479299340066L;
	
	private int num;
	private String problem;
	private String state;
	private String answer;
	private long startTime;
	private String type;
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getProblem() {
		return problem;
	}
	public void setProblem(String problem) {
		this.problem = problem;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public long getStartTime() {
		return startTime;
	}
	public void setStartTime(long startTime) {
		this.startTime = startTime;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	@Override
	public String toString() {
		return "ProblemTable [num=" + num + ", problem=" + problem + ", state=" + state + ", answer=" + answer
				+ ", startTime=" + startTime + ", type=" + type + "]";
	}

}
