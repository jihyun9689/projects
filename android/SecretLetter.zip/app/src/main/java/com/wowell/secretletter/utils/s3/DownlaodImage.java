package com.wowell.secretletter.utils.s3;

import android.content.Context;

import com.amazonaws.mobileconnectors.s3.transferutility.TransferListener;
import com.amazonaws.mobileconnectors.s3.transferutility.TransferObserver;
import com.wowell.secretletter.utils.save.InternalStorage;
import com.wowell.secretletter.utils.logger.LogManager;

import java.io.File;


/**
 * Created by kim on 2016-01-18.
 */
public class DownlaodImage extends S3Util{


    public static TransferObserver beginDownload(Context context, String folderName, TransferListener transferListener) {
        sTransferUtility = getTransferUtility(context);
        // Location to download files from S3 to. You can choose any accessible
        // file.
       // File file = new File(Environment.getExternalStorageDirectory().toString() + "/" + key);
        ;
        // Initiate the download

        File file = InternalStorage.saveJpgFile(folderName + ".png", context);
        LogManager.printLog(DownlaodImage.class,"friendName : " + folderName + ".png" + "   filePath : " + file.getAbsolutePath());

        TransferObserver observer = sTransferUtility.download(Constants.BUCKET_NAME,
                Constants.FOLDER_NAME_IN_S3_BUCKET + File.separator + folderName + File.separator + "problem.png",
                file);

        observer.setTransferListener(transferListener);

        return observer;
    }
}
