package com.wowell.secretletter.base.state;

import com.wowell.secretletter.utils.logger.LogManager;
import com.wowell.secretletter.utils.save.ManageSharedPreference;

/**
 * Created by kim on 2016-03-25.
 */
public class LoginState implements State<String> {

    public static final String LOGIN_STATE = "login";

    private String value = null;

    public static final String LOGON = "logon";
    public static final String LOGOUT = "logout";

    private static LoginState loginState = null;

    private LoginState() {
    }

    public static LoginState getInstance(){
        if(loginState == null){
            loginState = new LoginState();
        }
        return loginState;
    }

    @Override
    public void setValue(String value){
        this.value = value;
    }

    @Override
    public String getValue() {
        return value;
    }

    @Override
    public String getStateName() {
        return LOGIN_STATE;
    }

    @Override
    public void save(ManageSharedPreference manageSharedPreference) {
        manageSharedPreference.putValue(LOGIN_STATE, value, String.class);
    }

    @Override
    public void setting(ManageSharedPreference manageSharedPreference) {
        value = manageSharedPreference.getValue(LOGIN_STATE, LOGOUT, String.class);
        LogManager.printLog(getClass(),"LoginState value : " + value);
        MappingState.setState(LOGIN_STATE, loginState);
    }

    @Override
    public void delete(ManageSharedPreference manageSharedPreference) {
        manageSharedPreference.deleteValue(LoginState.LOGIN_STATE);
        value = LOGOUT;
    }


    @Override
    public boolean equals(Object o) {
        if(o instanceof String){
            if(value.equals(o)){
                return true;
            }else{
                return false;
            }
        }
        return super.equals(o);
    }
}
