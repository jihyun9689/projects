package com.wowell.secretletter.feature.main.tabs.letterStorage;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.wowell.secretletter.R;
import com.wowell.secretletter.base.BaseFragment;
import com.wowell.secretletter.model.ProblemTable;
import com.wowell.secretletter.model.RankingList;
import com.wowell.secretletter.utils.http.RequestThread;
import com.wowell.secretletter.utils.json.JSONProductParser;
import com.wowell.secretletter.utils.logger.LogManager;
import com.wowell.secretletter.utils.s3.Constants;
import com.wowell.secretletter.utils.s3.S3Util;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by kim on 2016-04-12.
 */
public class LetterStorageFragment extends BaseFragment {
    ListView listView;
    LetterStorageListAdapter letterStorageListAdapter;
    ArrayList<ProblemTable> problemTables = new ArrayList<>();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_letter_storage, container, false);
        listView = (ListView)view.findViewById(R.id.letter_storage_listview);

        init();
        return view;
    }

    @Override
    protected void init() {
        letterStorageListAdapter = new LetterStorageListAdapter(getActivity());
        letterStorageListAdapter.setItem(problemTables);
        listView.setAdapter(letterStorageListAdapter);
        getAllList();
    }

    private void getAllList(){
        List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        nameValuePairs.add(new BasicNameValuePair("action", "get_all_list"));
        RequestThread requestThread = new RequestThread("problem.do", nameValuePairs, new ProblemAllListRequestHandler());
        requestThread.start();
    }

    private class ProblemAllListRequestHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            Bundle bundle = msg.getData();
            if(bundle != null){
                String data = bundle.getString("data");
                LogManager.printLog(getClass(), "TotalRankingRequestHandler data : " + data);
                new GetProblemListTask().execute(data);
            }

            switch (msg.what){
                case RequestThread.SUCCESS:
                    LogManager.printLog(getClass(),"ProblemAllListRequestHandler SUCCESS");
                    break;
                case RequestThread.FAIL:
                    LogManager.printLog(getClass(),"ProblemAllListRequestHandler FAIL");
                    break;

            }
        }
    }

    private class GetProblemListTask extends AsyncTask<String, Void, Void> {

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected Void doInBackground(String... inputs) {
            LogManager.printLog(getClass(),inputs[0]);
            problemTables = JSONProductParser.problemParser(inputs[0]);
            letterStorageListAdapter.setItem(problemTables);
            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            letterStorageListAdapter.notifyDataSetChanged();
        }
    }
}
