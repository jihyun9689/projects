package com.wowell.secretletter.view.answerSheet;

/**
 * Created by kim on 2016-03-28.
 */
public class AnswerSheetType {
    public static final int SHORT_ANSWER = 0;
    public static final int MULTIPLE_CHOICE = 1;

}
