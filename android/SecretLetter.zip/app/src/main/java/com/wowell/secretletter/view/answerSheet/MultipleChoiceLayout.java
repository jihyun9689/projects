package com.wowell.secretletter.view.answerSheet;

import android.content.Context;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.wowell.secretletter.R;
import com.wowell.secretletter.utils.http.LoadImageFromURL;
import com.wowell.secretletter.utils.logger.LogManager;

import java.io.File;

/**
 * Created by kim on 2016-03-28.
 */
public class MultipleChoiceLayout extends AnswerSheet {
    Context context;
    String problemName;
    String result = null;
    public MultipleChoiceLayout(Context context, String problemName) {
        super(context);
        this.context = context;
        this.problemName = problemName;
        init();
    }

    public MultipleChoiceLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    String getAnswer() {
        return result;
    }

    private void init(){
        setOrientation(VERTICAL);

        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        int width = dm.widthPixels;
        LogManager.printLog(getClass(), "width : " + width);
        addView(newLinearLayout(context, width, 0));
        addView(newLinearLayout(context, width, 1));}

    private LinearLayout newLinearLayout(Context context, int windowWidth, int rowNum){
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        LinearLayout linearLayout = (LinearLayout)layoutInflater.inflate(R.layout.view_multiple_choice, null);
        LayoutParams layoutParams = new LayoutParams(windowWidth, windowWidth / 3);
        linearLayout.setLayoutParams(layoutParams);
        linearLayout.setOrientation(HORIZONTAL);
        linearLayout.setPadding(10, 10, 10, 10);


        LinearLayout rowLayout1 = (LinearLayout)linearLayout.findViewById(R.id.multiple_choice_layout1);
        rowLayout1.addView(problemImageView(context, String.valueOf(rowNum * 3 + 1)));

        LinearLayout rowLayout2 = (LinearLayout)linearLayout.findViewById(R.id.multiple_choice_layout2);
        rowLayout2.addView(problemImageView(context, String.valueOf(rowNum * 3 + 2)));

        LinearLayout rowLayout3 = (LinearLayout)linearLayout.findViewById(R.id.multiple_choice_layout3);
        rowLayout3.addView(problemImageView(context, String.valueOf(rowNum * 3 + 3)));

        return linearLayout;
    }

    private LinearLayout newEachRowLayout(Context context){
        LinearLayout linearLayout = new LinearLayout(context);
        LayoutParams layoutParams = new LayoutParams(0, LayoutParams.MATCH_PARENT);
        linearLayout.setWeightSum(1);
        linearLayout.setLayoutParams(layoutParams);
        return linearLayout;
    }

    private ImageView problemImageView(Context context,String answerNum){
        ImageView imageView = new ImageView(context);
        LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        imageView.setLayoutParams(params);
        imageView.setScaleType(ImageView.ScaleType.FIT_XY);
        LoadImageFromURL.loadBitmap(problemName + File.separator + "answer" + answerNum + ".png", imageView);
        imageView.setOnClickListener(new ClickListener(answerNum));
        return imageView;
    }

    private class ClickListener implements OnClickListener {
        String answerNum;

        public ClickListener(String answerNum) {
            this.answerNum = answerNum;
        }

        @Override
        public void onClick(View v) {
            result = answerNum;
        }
    }
}
