package com.wowell.secretletter.feature.main;

/**
 * Created by kim on 2016-04-19.
 */
public interface GcmListener {
    public void messageHandler(String message);
}
