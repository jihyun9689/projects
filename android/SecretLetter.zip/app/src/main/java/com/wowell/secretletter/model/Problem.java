package com.wowell.secretletter.model;

/**
 * Created by kim on 2016-04-19.
 */
public class Problem {
}
