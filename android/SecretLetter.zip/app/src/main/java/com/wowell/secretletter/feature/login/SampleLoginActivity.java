/**
 * Copyright 2014 Daum Kakao Corp.
 *
 * Redistribution and modification in source or binary forms are not permitted without specific prior written permission. 
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.wowell.secretletter.feature.login;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.kakao.auth.ISessionCallback;
import com.kakao.auth.KakaoSDK;
import com.kakao.auth.Session;
import com.kakao.usermgmt.LoginButton;
import com.kakao.util.exception.KakaoException;
import com.kakao.util.helper.log.Logger;

import com.wowell.secretletter.R;
import com.wowell.secretletter.base.BaseActivity;
import com.wowell.secretletter.base.state.LoginState;
import com.wowell.secretletter.base.state.MappingState;
import com.wowell.secretletter.base.state.State;
import com.wowell.secretletter.controller.StateController;
import com.wowell.secretletter.utils.logger.LogManager;

/**
 * 샘플에서 사용하게 될 로그인 페이지
 * 세션을 오픈한 후 action을 override해서 사용한다.
 *
 * @author MJ
 */
public class SampleLoginActivity extends BaseActivity {
    private SessionCallback callback;
    LinearLayout linearLayout;
    TextView touchTextView;
    LoginButton loginButton;

    /**
     * 로그인 버튼을 클릭 했을시 access token을 요청하도록 설정한다.
     *
     * @param savedInstanceState 기존 session 정보가 저장된 객체
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LogManager.printLog(getClass(), "SampleLoginActivity");
        setContentView(R.layout.layout_common_kakao_login);
        linearLayout = (LinearLayout)findViewById(R.id.login_background_linearlayout);
        touchTextView = (TextView)findViewById(R.id.login_touch_textview);
        loginButton = (LoginButton)findViewById(R.id.com_kakao_login);

        try{
            KakaoSDK.init(getKakaoSDKAdapter());
        }catch (KakaoSDK.AlreadyInitializedException e){
            LogManager.printError(getClass(), e.getMessage());
        }

        callback = new SessionCallback();
        Session.getCurrentSession().addCallback(callback);
        if (!Session.getCurrentSession().checkAndImplicitOpen()) {
            touchTextView.setVisibility(View.INVISIBLE);
            loginButton.setVisibility(View.VISIBLE);
            LogManager.printLog(getClass(), "!Session.getCurrentSession().checkAndImplicitOpen()");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (Session.getCurrentSession().handleActivityResult(requestCode, resultCode, data)) {
            return;
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Session.getCurrentSession().removeCallback(callback);
    }

    @Override
    protected void onStart() {
        super.onStart();
        LogManager.printLog(getClass(),"onStart activity");
    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    private class SessionCallback implements ISessionCallback {

        @Override
        public void onSessionOpened() {
            LogManager.printLog(getClass(), "SessionCallback onSessionOpened");

            State state = MappingState.getState(LoginState.LOGIN_STATE);
            state.setValue(LoginState.LOGON);

            touchTextView.setVisibility(View.VISIBLE);
            loginButton.setVisibility(View.INVISIBLE);
            linearLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(SampleLoginActivity.this, SampleSignupActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                    startActivity(intent);
                    finish();
                }
            });
        }

        @Override
        public void onSessionOpenFailed(KakaoException exception) {
            if(exception != null) {
                Logger.e(exception);
            }
            LogManager.printLog(getClass(), "SessionCallback onSessionOpenFailed");
            touchTextView.setVisibility(View.INVISIBLE);
            loginButton.setVisibility(View.VISIBLE);
            Toast.makeText(getApplicationContext(),"다시 시도해주세요.",Toast.LENGTH_SHORT).show();
//            setContentView(R.layout.layout_common_kakao_login);
        }
    }

    private void checkLoginState(){
        State state = MappingState.getState(LoginState.LOGIN_STATE);
        if(state.equals(LoginState.LOGON)){

        }else{

        }
    }
}
