package com.wowell.secretletter.utils.gcm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.app.Activity;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;

import java.util.ArrayList;

/**
 * Created by kim on 2016-02-04.
 */
public class TopicsController {
    public static final int SUBSCRIBE = 0;
    public static final int UNSUBSCRIBE = 1;
    public static final int SUBSCRIBE_ALL_TOPICS = 2;

    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
    private static final String TAG = "MainActivity";

    private BroadcastReceiver mRegistrationBroadcastReceiver;
    private ProgressBar mRegistrationProgressBar;
    private TextView mInformationTextView;

    static ArrayList<String> topics = new ArrayList<>();

    static public void setTopics(Context context){
        topics.add("public");
        subscribeAllTopics(context);
    }

    static public void addTopic(Context context, String friendId){

        topics.add("R_"+ friendId);

        subscribeTopic(context, "R_"+ friendId);
    }

    static public void deleteTopic(Context context, String friendId){

        topics.remove("R_"+ friendId);

        unsubscribeTopic(context,"R_"+ friendId);
    }

    static public ArrayList<String> getTopics(){
        return topics;
    }

    static public void subscribeAllTopics(Context context){

        Intent intent = new Intent(context, RegistrationIntentService.class);
        intent.putExtra("type", SUBSCRIBE_ALL_TOPICS);
        intent.putExtra("subscribe_totaltopics", topics);
        context.startService(intent);
    }

    static public void destroyTopics(){
        topics.clear();
    }




    static private void subscribeTopic(Context context, String topic){
        Intent intent = new Intent(context, RegistrationIntentService.class);
        intent.putExtra("type", SUBSCRIBE);
        intent.putExtra("subscribe_topic", topic);
        context.startService(intent);
    }

    static private void unsubscribeTopic(Context context, String topic){
        Intent intent = new Intent(context, RegistrationIntentService.class);
        intent.putExtra("type", UNSUBSCRIBE);
        intent.putExtra("unsubscribe_topic", topic);
        context.startService(intent);
    }
}
