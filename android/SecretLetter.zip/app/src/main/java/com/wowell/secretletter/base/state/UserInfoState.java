package com.wowell.secretletter.base.state;

import com.wowell.secretletter.utils.save.ManageSharedPreference;

/**
 * Created by kim on 2016-03-26.
 */
public class UserInfoState implements State<String> {
    public static final String USER_INFO_STATE = "user_info";

    private static UserInfoState userInfoState = null;

    private String value = null;

    public static final String UNREGISTERED = "unregistered";
    public static final String REGISTERED = "registered";

    private UserInfoState() {
    }

    public static UserInfoState getInstance(){
        if(userInfoState == null){
            userInfoState = new UserInfoState();
        }
        return userInfoState;
    }

    @Override
    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String getValue() {
        return null;
    }

    @Override
    public String getStateName() {
        return USER_INFO_STATE;
    }

    @Override
    public void save(ManageSharedPreference manageSharedPreference) {
        manageSharedPreference.putValue(USER_INFO_STATE, value, String.class);
    }

    @Override
    public void setting(ManageSharedPreference manageSharedPreference) {
        value = manageSharedPreference.getValue(USER_INFO_STATE, UNREGISTERED, String.class);
        MappingState.setState(USER_INFO_STATE, userInfoState);
    }

    @Override
    public void delete(ManageSharedPreference manageSharedPreference) {
        manageSharedPreference.deleteValue(UserInfoState.USER_INFO_STATE);
        value = UNREGISTERED;
    }


    @Override
    public boolean equals(Object o) {

        if(o instanceof String){
            if(value.equals(o)){
                return true;
            }else{
                return false;
            }
        }

        return super.equals(o);
    }
}
