package com.wowell.secretletter.feature.main.tabs.story;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.wowell.secretletter.R;
import com.wowell.secretletter.base.BaseFragment;

/**
 * Created by kim on 2016-04-12.
 */
public class StoryFragmnet extends BaseFragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_my_info, container, false);

        init();
        return view;
    }

    @Override
    protected void init() {

    }
}
