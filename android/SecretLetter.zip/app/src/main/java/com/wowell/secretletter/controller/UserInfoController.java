package com.wowell.secretletter.controller;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;

import com.wowell.secretletter.model.MyInfo;
import com.wowell.secretletter.utils.http.RequestThread;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kim on 2016-04-02.
 */
public class UserInfoController {
    private static MyInfo myInfo = new MyInfo();

    public static MyInfo getMyInfo() {
        return myInfo;
    }

    public static void setMyInfo(MyInfo myInfo) {
        UserInfoController.myInfo = myInfo;
    }

    public static void saveUserInfoServer(MyInfo myInfo, Handler handler){
        List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        //key, value
        nameValuePairs.add(new BasicNameValuePair("action", "insert")); //TODO register ID
        nameValuePairs.add(new BasicNameValuePair("kakao_id", myInfo.getKakaoId()));
        nameValuePairs.add(new BasicNameValuePair("nickname", myInfo.getUserName()));
        nameValuePairs.add(new BasicNameValuePair("university", myInfo.getUniversity()));
        nameValuePairs.add(new BasicNameValuePair("major", myInfo.getMajor()));

        RequestThread requestThread = new RequestThread("userInfo.do", nameValuePairs, handler);
        requestThread.start();
    }

    public static void getUserIdServer(MyInfo myInfo, Handler handler){
        List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
        //key, value
        nameValuePairs.add(new BasicNameValuePair("action", "get_id")); //TODO register ID
        nameValuePairs.add(new BasicNameValuePair("kakao_id", myInfo.getKakaoId()));
        nameValuePairs.add(new BasicNameValuePair("nickname", myInfo.getUserName()));

        RequestThread requestThread = new RequestThread("userInfo.do", nameValuePairs, handler);
        requestThread.start();
    }

    public static void saveUserInfoInLocalStorage(Context context){
        SharedPreferences sharedPreferences = context.getSharedPreferences("pre", Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("user_id", myInfo.getUserId());
        editor.putString("user_name", myInfo.getUserName());
        editor.putString("user_university", myInfo.getUniversity());
        editor.putString("user_major", myInfo.getMajor());
        editor.commit();
    }

    public static void loadUserInfoInLocalStorage(Context context){
        SharedPreferences sharedPreferences = context.getSharedPreferences("pre", Activity.MODE_PRIVATE);
        myInfo.setUserId(sharedPreferences.getString("user_id", ""));
        myInfo.setUserName(sharedPreferences.getString("user_name", ""));
        myInfo.setUniversity(sharedPreferences.getString("user_university", ""));
        myInfo.setMajor(sharedPreferences.getString("user_major", ""));
    }

    public static void deleteLocalStorage(Context context){
        SharedPreferences sharedPreferences = context.getSharedPreferences("pre", Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.remove("user_id");
        editor.remove("user_name");
        editor.remove("user_university");
        editor.remove("user_major");
        editor.commit();
    }
}
