package com.wowell.secretletter.base;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

import android.support.v7.app.ActionBar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.wowell.secretletter.R;
import com.wowell.secretletter.feature.main.MainActivity;
import com.wowell.secretletter.feature.main.MainFragment;
import com.wowell.secretletter.utils.logger.LogManager;


/**
 * Created by kim on 2016-03-08.
 */
public abstract class BaseFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    protected void setActionBarTitle(String title){
        ((MainActivity)getActivity()).getSupportActionBar().setDisplayUseLogoEnabled(false);
        ((MainActivity)getActivity()).getSupportActionBar().setTitle(title);
    }

    protected abstract void init();

    public TabLayout setTabLayout(boolean enable){

        TabLayout tabs = (TabLayout) getActivity().findViewById(R.id.tabs);

        if(enable){
            tabs.setVisibility(View.VISIBLE);
            tabs.removeAllTabs();

        }else{
            tabs.setVisibility(View.GONE);
        }

        return tabs;
    }

    public void setTiltle(String title){
        getActivity().setTitle(title);
    }

    public void setHomeButtonBackPress(boolean enable){
        ActionBar actionBar = ((MainActivity)getActivity()).getSupportActionBar();
        //Enable or disable the "home" button in the corner of the action bar.
        actionBar.setHomeButtonEnabled(enable);
        //Set whether to include the application home affordance in the action bar.
        actionBar.setDisplayShowHomeEnabled(enable);
        //Set whether home should be displayed as an "up" affordance.
        actionBar.setDisplayHomeAsUpEnabled(enable);
    }

    public void mainFragmentHomeButton(boolean enable){
        ActionBar actionBar = ((MainActivity)getActivity()).getSupportActionBar();
        if(enable){
            actionBar.setHomeButtonEnabled(enable);
            actionBar.setDisplayHomeAsUpEnabled(!enable);
            actionBar.setDisplayShowHomeEnabled(enable);

        }else{
            actionBar.setHomeButtonEnabled(!enable);
            actionBar.setDisplayHomeAsUpEnabled(enable);
            actionBar.setDisplayShowHomeEnabled(!enable);
        }
    }

    protected MainActivity getMainActivity(){
        return (MainActivity)getActivity();
    }
}
