package com.wowell.secretletter.model.gcm;

public class GcmPackage {

	public String kind;

	public String getKind() {
		return kind;
	}

	public void setKind(String kind) {
		this.kind = kind;
	}
}
