package com.wowell.secretletter.feature.main.menu.ranking;


import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.wowell.secretletter.R;
import com.wowell.secretletter.base.BaseFragment;
import com.wowell.secretletter.feature.main.MainFragment;
import com.wowell.secretletter.feature.main.menu.ranking.totalRanking.TotalRankingFragment;
import com.wowell.secretletter.utils.logger.LogManager;

/**
 * Created by kim on 2016-03-22.
 */
public class RankingFragment extends BaseFragment {
    ViewPager pager;
    TabLayout tabs;
    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_ranking, container, false);

        pager = (ViewPager)view.findViewById(R.id.ranking_viewpager);

        init();
        return view;
    }

    @Override
    protected void init() {
        tabs = setTabLayout(true);
        setTiltle("랭킹보기");
        //((MainActivity)getActivity()).fragmentToolBarSetting();
        setHomeButtonBackPress(true);

        tabs.addTab(tabs.newTab().setText("나의 친구"));
        tabs.addTab(tabs.newTab().setText("taltal 보내기"));
        tabs.addTab(tabs.newTab().setText("poster 보내기"));

        PagerAdapter pagerAdapter = new ViewPagerAdapter(getChildFragmentManager());
        pager.setAdapter(pagerAdapter);
        pager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabs));

        //먼저 로딩하는 페이지의 갯수 설정
        pager.setOffscreenPageLimit(2);


        tabs.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                pager.setCurrentItem(tab.getPosition());

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.findItem(R.id.menu_ranking).setVisible(false);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        LogManager.printLog(getClass(),"item.getItemId() : " + id );
        //noinspection SimplifiableIfStatement
        if (id == R.id.menu_ranking) {
            return false;
        }else if(id == android.R.id.home){
            MainFragment mainFragment = new MainFragment();
            getMainActivity().replaceFragment(mainFragment, false);

            LogManager.printLog(getClass(),"onOptionsItemSelected android.R.id.home");
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private class ViewPagerAdapter extends FragmentStatePagerAdapter {

        public ViewPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            Fragment fragment = null;

            if(position == 0){

                fragment = new TotalRankingFragment();
            }else if(position == 1){
                fragment = new TotalRankingFragment();
            }else if(position == 2){
                fragment = new TotalRankingFragment();
            }
            return fragment;
        }

        @Override
        public int getCount() {
            return 3;
        }
    }
}
