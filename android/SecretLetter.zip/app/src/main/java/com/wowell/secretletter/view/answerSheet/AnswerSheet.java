package com.wowell.secretletter.view.answerSheet;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.LinearLayout;

/**
 * Created by kim on 2016-03-29.
 */
public abstract class AnswerSheet extends LinearLayout {
    public AnswerSheet(Context context) {
        super(context);
    }

    public AnswerSheet(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    abstract String getAnswer();
}
