package com.wowell.secretletter.feature.floatingWindow;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.os.Build;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.wowell.secretletter.R;
import com.wowell.secretletter.feature.login.SampleLoginActivity;
import com.wowell.secretletter.utils.logger.LogManager;

/**
 * Created by kim on 2016-03-25.
 */
public class FloatingWindowActivity extends Service {

    private WindowManager windowManager;
    private LinearLayout linearLayout;
    WindowManager.LayoutParams windowLayoutParams;
    Intent serviceIntent;
    boolean longClickedFloationWindow = false;
    ImageView imageView;
    ImageView circleImageview;
    WindowManager.LayoutParams circleLayoutParams;

    int width;
    int height;
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        serviceIntent = intent;
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        LogManager.printLog(getClass(), "onCreate Service");

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        DisplayMetrics dm = getApplicationContext().getResources().getDisplayMetrics();
        width = dm.widthPixels;
        height = dm.heightPixels;

        LogManager.printLog(getClass(),"height : " + height + " width : " + width);

        linearLayout = new LinearLayout(this);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        linearLayout.setBackgroundColor(Color.argb(66, 255, 0, 0));
        linearLayout.setLayoutParams(layoutParams);

        imageView = new ImageView(getApplicationContext());
        LinearLayout.LayoutParams imageParmas = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        imageView.setImageResource(R.drawable.envelope);
        imageView.setLayoutParams(imageParmas);
        linearLayout.setOnLongClickListener(onLongClickListener);
        linearLayout.setOnTouchListener(onTouchListener);
        linearLayout.addView(imageView);

        circleImageview = new ImageView(getApplicationContext());
        circleImageview.setBackgroundResource(R.drawable.btn_a);
        LinearLayout.LayoutParams circleParmas = new LinearLayout.LayoutParams(200, 200);
        circleImageview.setLayoutParams(circleParmas);

        circleLayoutParams = new WindowManager.LayoutParams(
                200,
                200,
                WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        circleLayoutParams.x = 0;
        circleLayoutParams.y = height / 2;



        windowLayoutParams = new WindowManager.LayoutParams(
                200,
                200,
                WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);

        windowLayoutParams.x = width / 2;
        windowLayoutParams.y = 0;

        windowManager.addView(linearLayout, windowLayoutParams);

    }

    View.OnLongClickListener onLongClickListener = new View.OnLongClickListener() {
        @Override
        public boolean onLongClick(View v) {
            LogManager.printLog(getClass(),"onLongClickListener ");
            longClickedFloationWindow = true;
            windowManager.addView(circleImageview, circleLayoutParams);
            return false;
        }
    };

    View.OnTouchListener onTouchListener = new View.OnTouchListener() {
        private int initialX;
        private int initialY;
        private float initialTouchX;
        private float initialTouchY;

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
                        imageView.setAlpha(0.5f);
                    }
                    initialX = windowLayoutParams.x;
                    initialY = windowLayoutParams.y;
                    LogManager.printLog(getClass(),"windowLayoutParams.x : " + windowLayoutParams.x + " windowLayoutParams.y : " + windowLayoutParams.y );
                    initialTouchX = event.getRawX();
                    initialTouchY = event.getRawY();
                    LogManager.printLog(getClass(),"initialTouchX : " + initialTouchX + " initialTouchY : " + initialTouchY );


                    return false;
                case MotionEvent.ACTION_UP:
                    if(longClickedFloationWindow){
                        windowManager.removeView(circleImageview);
                    }
                    longClickedFloationWindow = false;
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
                        imageView.setAlpha(1f);
                    }



                    if(Math.abs(windowLayoutParams.x - initialX) < 10 && Math.abs(windowLayoutParams.y - initialY) < 10) {
                        //페이지 이동
                        Toast.makeText(getBaseContext(), "Test", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), SampleLoginActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);

                        windowManager.removeView(linearLayout);
                        stopSelf();
                    }else{
                        //위치 이동

                        if(event.getRawY() <  height / 3){
                            windowLayoutParams.x = width / 2;
                            windowLayoutParams.y = - height / 3;
                            windowManager.updateViewLayout(linearLayout, windowLayoutParams);
                            //windowManager.updateViewLayout(linearLayout, windowLayoutParams);
                        }else if(event.getRawY() >=  height / 3 && event.getRawY() < (height * 2) / 3){
                            windowLayoutParams.x = width / 2;
                            windowLayoutParams.y = 0;
                            windowManager.updateViewLayout(linearLayout, windowLayoutParams);
                        }else {
                            if( (event.getRawX() - (width / 2)) * (event.getRawX() - (width / 2)) + (event.getRawY() - height + 100) * (event.getRawY() - height + 100) < 10000){
                                windowManager.removeView(linearLayout);
                                stopSelf();
                            }
                            windowLayoutParams.x = width / 2;
                            windowLayoutParams.y = height / 3;
                            windowManager.updateViewLayout(linearLayout, windowLayoutParams);
                        }

                    }
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if(longClickedFloationWindow){
                        windowLayoutParams.x = initialX + (int) (event.getRawX() - initialTouchX);
                        windowLayoutParams.y = initialY + (int) (event.getRawY() - initialTouchY);

                        LogManager.printLog(getClass(), "event.getRawX() : " + (int) event.getRawX() + " event.getRawY() : " + (int) event.getRawY());

                        if( (event.getRawX() - (width / 2)) * (event.getRawX() - (width / 2)) + (event.getRawY() - height + 100) * (event.getRawY() - height + 100) < 10000){
                            circleImageview.setBackgroundResource(R.drawable.btn_b);
                        }else{
                            circleImageview.setBackgroundResource(R.drawable.btn_a);
                        }

                        windowManager.updateViewLayout(linearLayout, windowLayoutParams);
                        windowManager.updateViewLayout(circleImageview, circleLayoutParams);

                    }
                    return true;
            }
            return false;
        }
    };

    @Override
    public void onDestroy() {
        LogManager.printLog(getClass(),"onDestroy");
        super.onDestroy();
    }
}
