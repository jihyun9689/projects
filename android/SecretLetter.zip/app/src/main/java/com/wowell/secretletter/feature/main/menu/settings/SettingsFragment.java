package com.wowell.secretletter.feature.main.menu.settings;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.wowell.secretletter.R;
import com.wowell.secretletter.base.BaseFragment;
import com.wowell.secretletter.feature.main.MainFragment;

/**
 * Created by kim on 2016-03-25.
 */
public class SettingsFragment extends BaseFragment {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    protected void init() {

    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.findItem(R.id.menu_ranking).setVisible(false);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.menu_ranking) {
            return false;
        }else if(id == android.R.id.home){
            MainFragment mainFragment = new MainFragment();
            getMainActivity().replaceFragment(mainFragment, false);
        }

        return super.onOptionsItemSelected(item);
    }
}
