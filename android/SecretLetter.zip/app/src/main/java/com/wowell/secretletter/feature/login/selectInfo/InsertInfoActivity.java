package com.wowell.secretletter.feature.login.selectInfo;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;
import com.wowell.secretletter.R;
import com.wowell.secretletter.base.BaseActivity;
import com.wowell.secretletter.base.state.MappingState;
import com.wowell.secretletter.base.state.UserInfoState;
import com.wowell.secretletter.controller.UserInfoController;
import com.wowell.secretletter.feature.intro.Loading.LoadingActivity;
import com.wowell.secretletter.feature.main.MainActivity;
import com.wowell.secretletter.model.MyInfo;
import com.wowell.secretletter.utils.http.RequestThread;
import com.wowell.secretletter.utils.logger.LogManager;

/**
 * Created by kim on 2016-03-24.
 */
public class InsertInfoActivity extends BaseActivity{
    ImageView profileImage;
    EditText nickname;
    TextView universityTextView, majorTextView;
    Button nextBtn;

    public static final int UNIVERSITY_ACTIVITY_RESULT = 10;
    public static final int MAJOR_ACTIVITY_RESULT = 11;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        UserInfoState userInfoState = (UserInfoState)MappingState.getState(UserInfoState.USER_INFO_STATE);

        if(userInfoState.equals(UserInfoState.UNREGISTERED)){
            setContentView(R.layout.activity_insert_info);

            profileImage = (ImageView)findViewById(R.id.insert_info_profile_imageview);
            nickname = (EditText)findViewById(R.id.insert_info_nickname_edittext);
            universityTextView = (TextView)findViewById(R.id.insert_info_university_textview);
            majorTextView = (TextView)findViewById(R.id.insert_info_major_textview);
            nextBtn = (Button)findViewById(R.id.insert_next_btn);

            init();
        }else{

            Intent intent = new Intent(InsertInfoActivity.this, LoadingActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
            startActivity(intent);
            finish();
        }
    }

    private void init(){
        LogManager.printLog(getClass(), "myInfo.toString : " + UserInfoController.getMyInfo().toString());

        if(UserInfoController.getMyInfo().getProfileUrl() != "" && !UserInfoController.getMyInfo().getProfileUrl().isEmpty()){
            //카톡 프로필 사진이 없을 때 널 포인트 에러 발생
            Picasso.with(this)
                    .load(UserInfoController.getMyInfo().getProfileUrl())
                    .fit()
                    .into(profileImage);
        }

        universityTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InsertInfoActivity.this, SelectInfoActivity.class);
                intent.putExtra("key","university");
                startActivityForResult(intent, UNIVERSITY_ACTIVITY_RESULT);

            }
        });

        majorTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InsertInfoActivity.this, SelectInfoActivity.class);
                intent.putExtra("key","major");
                startActivityForResult(intent, MAJOR_ACTIVITY_RESULT);
            }
        });

        nextBtn.setOnClickListener(onClickListener);
    }

    View.OnClickListener onClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            LogManager.printLog(getClass(),"MyInfo.getInstance() : " + UserInfoController.getMyInfo().toString());
            LogManager.printLog(getClass(),"nickname.getText().toString() : " + nickname.getText().toString());

            if(nickname.getText().toString().isEmpty() || nickname.getText().toString() == "") {
                Toast.makeText(getApplicationContext(),"이름을 등록해주세요.", Toast.LENGTH_SHORT).show();
            }else if(UserInfoController.getMyInfo().getUniversity() == null || UserInfoController.getMyInfo().getUniversity() == ""){
                Toast.makeText(getApplicationContext(),"대학교를 선택해주세요.", Toast.LENGTH_SHORT).show();
            }else if(UserInfoController.getMyInfo().getMajor() == null || UserInfoController.getMyInfo().getMajor() == ""){
                Toast.makeText(getApplicationContext(),"전공을 선택해주세요.", Toast.LENGTH_SHORT).show();
            }else{
                UserInfoController.getMyInfo().setUserName(nickname.getText().toString());
                UserInfoController.saveUserInfoServer(UserInfoController.getMyInfo(), new SendUserInfoServerHandler());
            }
        }
    };

    private class SendUserInfoServerHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what){
                case RequestThread.SUCCESS:

                    // 서버에서 ID를 가지고 온다.
                    // 서버에서 ID를 받아오고 나서 엑티비티 종료
                    UserInfoController.getUserIdServer(UserInfoController.getMyInfo(), new GetUserIdServerHandler());
                    break;
                case RequestThread.FAIL:
                    Toast.makeText(getApplicationContext(),"SaveUserIfoHandler error ", Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    }

    private class GetUserIdServerHandler extends Handler{
        @Override
        public void handleMessage(Message msg) {
            Bundle bundle = msg.getData();
            if(bundle != null){
                UserInfoController.getMyInfo().setUserId(bundle.getString("data"));

                Intent intent = new Intent(InsertInfoActivity.this, LoadingActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
                startActivity(intent);

                UserInfoState userInfoState = UserInfoState.getInstance();
                userInfoState.setValue(UserInfoState.REGISTERED);
                MappingState.setState(UserInfoState.USER_INFO_STATE, userInfoState);

                finish();
            }
            switch (msg.what){
                case RequestThread.SUCCESS:

                    break;
                case RequestThread.FAIL:
                    Toast.makeText(getApplicationContext(),"getUserIdOnServerHandler error ", Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        LogManager.printLog(getClass(),"requestCode : " + requestCode + " resultCode : " + resultCode);
        String result;
        switch(resultCode){
            case UNIVERSITY_ACTIVITY_RESULT:
                result = data.getStringExtra("result");
                universityTextView.setText(result);

                LogManager.printLog(getClass(),"UNIVERSITY_ACTIVITY_RESULT : " +  UserInfoController.getMyInfo());
                break;
            case MAJOR_ACTIVITY_RESULT:
                result = data.getStringExtra("result");
                majorTextView.setText(result);

                LogManager.printLog(getClass(),"MAJOR_ACTIVITY_RESULT : " + UserInfoController.getMyInfo());
                break;
        }
    }
}
