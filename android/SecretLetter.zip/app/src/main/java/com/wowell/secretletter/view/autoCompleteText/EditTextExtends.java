package com.wowell.secretletter.view.autoCompleteText;

import android.content.Context;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.inputmethod.InputMethodManager;
import android.widget.AutoCompleteTextView;

import com.wowell.secretletter.utils.logger.LogManager;

/**
 * Created by kim on 2016-02-23.
 */
public class EditTextExtends extends AutoCompleteTextView {
    public EditTextExtends(Context context) {
        super(context);
    }

    public EditTextExtends(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public EditTextExtends(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public boolean onKeyPreIme(int keyCode, KeyEvent event) {
        LogManager.printLog(getClass(),"keyCode : "+ keyCode + " event : " + event);

        InputMethodManager imm = (InputMethodManager)getContext().getSystemService(Context.INPUT_METHOD_SERVICE);

        if(isPopupShowing() && imm.isFullscreenMode()){
            LogManager.printLog(getClass(),"isPopupShowing() && imm.isFullscreenMode()");
            imm.hideSoftInputFromWindow(this.getWindowToken(), 0);
            return true;
        }else if(isPopupShowing()){
            LogManager.printLog(getClass(),"isPopupShowing()");
            dismissDropDown();
            return true;
        }

        LogManager.printLog(getClass(),"onKeyPreIme");

        return super.onKeyPreIme(keyCode, event);
    }

    public void finishSelectInfo(){

        dismissDropDown();
    }
}
