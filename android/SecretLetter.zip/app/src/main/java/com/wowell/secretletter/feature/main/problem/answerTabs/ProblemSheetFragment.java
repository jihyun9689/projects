package com.wowell.secretletter.feature.main.problem.answerTabs;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.wowell.secretletter.R;
import com.wowell.secretletter.base.BaseFragment;
import com.wowell.secretletter.controller.ProblemController;
import com.wowell.secretletter.utils.logger.LogManager;


/**
 * Created by kim on 2016-04-14.
 */
public class ProblemSheetFragment extends BaseFragment {
    TextView problemTextView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragment_problem_sheet, container, false);
        problemTextView = (TextView) view.findViewById(R.id.problem_sheet_problem_textview);

        init();
        return view;
    }

    @Override
    protected void init() {
        if(ProblemController.getProblemGCM() != null){
            problemTextView.setText(ProblemController.getProblemGCM().getProblemText());
        }
    }
}
