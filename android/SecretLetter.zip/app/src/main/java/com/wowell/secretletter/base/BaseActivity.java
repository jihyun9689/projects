package com.wowell.secretletter.base;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;

import com.kakao.auth.ApprovalType;
import com.kakao.auth.AuthType;
import com.kakao.auth.IApplicationConfig;
import com.kakao.auth.ISessionConfig;
import com.kakao.auth.KakaoAdapter;
import com.wowell.secretletter.R;
import com.wowell.secretletter.base.state.TutorialState;
import com.wowell.secretletter.base.state.UserInfoState;
import com.wowell.secretletter.controller.ProblemController;
import com.wowell.secretletter.controller.StateController;
import com.wowell.secretletter.controller.UserInfoController;
import com.wowell.secretletter.feature.login.SampleLoginActivity;
import com.wowell.secretletter.utils.logger.LogManager;
/**
 * Created by kim on 2016-03-22.
 */
public class BaseActivity extends AppCompatActivity{
    public static KakaoAdapter kakaoAdapter = null;

    @Override
    public void onRequestPermissionsResult(int permsRequestCode, String[] permissions, int[] grantResults){

        switch(permsRequestCode){

            case 200:

                boolean writeAccepted = grantResults[0]== PackageManager.PERMISSION_GRANTED;
                LogManager.printLog(getClass(), "onRequestPermissionsResult : " + writeAccepted);
                break;

        }
    }

    public void permissionSetting(){
        //In Android 6(Marshmallow),
        // even though the user accepted all your permissions at install time,
        // they can later decide to take some of those permissions away from you.
        String[] perms = {
                "android.permission.SYSTEM_ALERT_WINDOW"
        };

        int permsRequestCode = 200;

        if (Build.VERSION.SDK_INT>Build.VERSION_CODES.LOLLIPOP_MR1) {
            requestPermissions(perms, permsRequestCode);
        }

        if(Build.VERSION.SDK_INT >= 23) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, 1234);
            }
        }
    }

    public KakaoAdapter getKakaoSDKAdapter(){
        KakaoAdapter kakaoAdapter = new KakaoAdapter(){
            @Override
            public ISessionConfig getSessionConfig() {
                return new ISessionConfig() {
                    @Override
                    public AuthType[] getAuthTypes() {
                        return new AuthType[] {AuthType.KAKAO_LOGIN_ALL};
                    }

                    @Override
                    public boolean isUsingWebviewTimer() {
                        return false;
                    }

                    @Override
                    public ApprovalType getApprovalType() {
                        return ApprovalType.INDIVIDUAL;
                    }

                    @Override
                    public boolean isSaveFormData() {
                        return true;
                    }
                };
            }

            @Override
            public IApplicationConfig getApplicationConfig() {
                return new IApplicationConfig() {
                    @Override
                    public Activity getTopActivity() {
                        return BaseActivity.this;
                    }

                    @Override
                    public Context getApplicationContext() {
                        return getApplication();
                    }
                };
            }
        };
        return kakaoAdapter;
    }

    public void redirectLoginActivity(){
        Intent intent = new Intent(this, SampleLoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onPause() {
        super.onPause();

        StateController.saveState(getApplicationContext());
        UserInfoController.saveUserInfoInLocalStorage(getApplicationContext());
        LogManager.printLog(getClass(), "onPause() ");

        ProblemController.setActivityFlag(false);
        ProblemController.saveMessage(getApplicationContext());
    }

    @Override
    protected void onStart() {
        super.onStart();

        StateController.settingState(getApplicationContext());
        UserInfoController.loadUserInfoInLocalStorage(getApplicationContext());
        LogManager.printLog(getClass(), "onStart()");

        ProblemController.setActivityFlag(true);
        ProblemController.settingMessage(getApplicationContext());

        LogManager.printLog(getClass(), "UserInfoState.getInstance().getValue() : " + UserInfoState.getInstance().getValue());
        LogManager.printLog(getClass(), "TutorialState.getInstance().getValue() : " + TutorialState.getInstance().getValue());
    }

    public void replaceFragment(Fragment fragment, boolean backStack){
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment_container, fragment);

        //백 스택을 저장하여 백키를 누를때 이전의 fragment로 이동하도록 한다.
        if(backStack){
            fragmentTransaction.addToBackStack(null);
        }else{
            clearStack(fragmentManager);
        }
        fragmentTransaction.commit();
    }

    private void clearStack(FragmentManager fm){
        int count = fm.getBackStackEntryCount();
        LogManager.printLog(getClass(), "count = " + count);
        for(int i = 0 ; i < count ; i ++){
            fm.popBackStack();
        }
    }

//    public void drawerLayoutSetting(Toolbar toolbar,NavigationView navigationView, NavigationView.OnNavigationItemSelectedListener onNavigation){
//        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
//        android.support.v7.app.ActionBarDrawerToggle toggle = new android.support.v7.app.ActionBarDrawerToggle(
//                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
//        drawer.setDrawerListener(toggle);
//        drawer.setDrawerListener(new DrawerLayout.DrawerListener() {
//            @Override
//            public void onDrawerSlide(View drawerView, float slideOffset) {
//
//            }
//
//            @Override
//            public void onDrawerOpened(View drawerView) {
//
//            }
//
//            @Override
//            public void onDrawerClosed(View drawerView) {
//
//            }
//
//            @Override
//            public void onDrawerStateChanged(int newState) {
//
//            }
//        });
//        toggle.syncState();
//
//        //navigationView.setNavigationItemSelectedListener(onNavi(enable);
//
//    }
}
