package com.wowell.secretletter.model;

import com.wowell.secretletter.utils.logger.LogManager;

/**
 * Created by kim on 2016-03-24.
 */
public class MyInfo {

    private String userName;
    private String kakaoNickname;
    private String userId;
    private String kakaoId;
    private String profileUrl;
    private String university;
    private String major;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getKakaoNickname() {
        return kakaoNickname;
    }

    public void setKakaoNickname(String kakaoNickname) {
        this.kakaoNickname = kakaoNickname;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getKakaoId() {
        return kakaoId;
    }

    public void setKakaoId(String kakaoId) {
        this.kakaoId = kakaoId;
    }

    public String getProfileUrl() {
        return profileUrl;
    }

    public void setProfileUrl(String profileUrl) {
        this.profileUrl = profileUrl;
    }

    public String getUniversity() {
        return university;
    }

    public void setUniversity(String university) {
        this.university = university;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    @Override
    public String toString() {
        return "MyInfo{" +
                "userName='" + userName + '\'' +
                ", userId='" + userId + '\'' +
                ", profileUrl='" + profileUrl + '\'' +
                ", university='" + university + '\'' +
                ", major='" + major + '\'' +
                '}';
    }
}
