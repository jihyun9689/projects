//package com.wowell.secretletter.base.state;
//
//import com.wowell.secretletter.utils.logger.LogManager;
//import com.wowell.secretletter.utils.save.ManageSharedPreference;
//
///**
// * Created by kim on 2016-03-25.
// */
//public class ProblemState implements State<String> {
//
//    public static String PROBLEM_STATE = "problem";
//
//    private static ProblemState problemState = null;
//
//    private String value = null;
//
//    public static final String UNSOLVED = "unsolved";
//    public static final String SOLVED = "solved";
//
//    private ProblemState() {
//    }
//
//    public static ProblemState getInstance(){
//        if(problemState == null){
//            problemState = new ProblemState();
//        }
//        return problemState;
//    }
//
//    @Override
//    public void setValue(String value){
//        this.value = value;
//    }
//
//    @Override
//    public String getValue() {
//        return value;
//    }
//
//    @Override
//    public String getStateName() {
//        return PROBLEM_STATE;
//    }
//
//    @Override
//    public void save(ManageSharedPreference manageSharedPreference) {
//        manageSharedPreference.putValue(PROBLEM_STATE, value, String.class);
//    }
//
//    @Override
//    public void setting(ManageSharedPreference manageSharedPreference) {
//        value = manageSharedPreference.getValue(PROBLEM_STATE, SOLVED, String.class);
//        LogManager.printLog(getClass(), "ProblemState value : " + value);
//        MappingState.setState(PROBLEM_STATE, problemState);
//    }
//
//    @Override
//    public boolean equals(Object o) {
//
//        if(o instanceof String){
//            if(value.equals(o)){
//                return true;
//            }else{
//                return false;
//            }
//        }
//
//        return super.equals(o);
//    }
//}
