package com.wowell.secretletter.base.state;

import com.wowell.secretletter.utils.save.ManageSharedPreference;

public interface State<T> {
    public void setValue(T value);
    public T getValue();
    public String getStateName();
    public void save(ManageSharedPreference manageSharedPreference);
    public void setting(ManageSharedPreference manageSharedPreference);
    public void delete(ManageSharedPreference manageSharedPreference);
    public boolean equals(Object o);
}
