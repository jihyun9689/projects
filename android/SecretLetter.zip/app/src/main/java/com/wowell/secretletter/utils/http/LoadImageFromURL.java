package com.wowell.secretletter.utils.http;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.widget.ImageView;

import com.wowell.secretletter.utils.logger.LogManager;

import java.io.File;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;

import com.wowell.secretletter.R;
import com.wowell.secretletter.utils.s3.Constants;

/**
 * Created by kim on 2016-02-12.
 */
public class LoadImageFromURL {
    private static final String TAG = "PosterController";

    public static void loadBitmap(String urlKey, ImageView imageView) {
        if (cancelPotentialDownload(urlKey, imageView)) {
            DownloadImageTask task = new DownloadImageTask(imageView);
            DownloadedDrawable downloadedDrawable = new DownloadedDrawable(task);
            imageView.setImageDrawable(downloadedDrawable);
            task.execute(urlKey);
        }
    }

    // there's no guarantee that the download tasks will finish in the order in which they were started.
    // The result is that the image finally displayed in the list may come from a previous item,
    // which simply happened to have taken longer to download.
    // This is not an issue if the images you download are bound once and for all to given ImageViews,
    //we should remember the order of the downloads, so that the last started one is the one that will effectively be displayed.
    // It is indeed sufficient for each ImageView to remember its last download

    static class DownloadedDrawable extends ColorDrawable {
        private static WeakReference<DownloadImageTask> bitmapDownloaderTaskReference = null;

        public DownloadedDrawable(DownloadImageTask bitmapDownloaderTask) {
            super(Color.BLACK);
            bitmapDownloaderTaskReference =
                    new WeakReference<DownloadImageTask>(bitmapDownloaderTask);
        }

        public static DownloadImageTask getBitmapDownloaderTask() {
            return bitmapDownloaderTaskReference.get();
        }
    }

    //The cancelPotentialDownload method will stop the possible download in progress on this imageView since a new one is about to start.
    // Note that this is not sufficient to guarantee that the newest download is always displayed, since the task may be finished,
    // waiting in its onPostExecute method, which may still may be executed after the one of this new download.
    //cancelPotentialDownload uses the cancel method of the AsyncTask class to stop the download in progress.
    // It returns true most of the time, so that the download can be started in download.
    // The only reason we don't want this to happen is when a download is already in progress on the same URL in which case we let it continue.
    // Note that with this implementation, if an ImageView is garbage collected, its associated download is not stopped. A RecyclerListener might be used for that.

    private static boolean cancelPotentialDownload(String url, ImageView imageView) {
        DownloadImageTask bitmapDownloaderTask = getBitmapDownloaderTask(imageView);

        if (bitmapDownloaderTask != null) {
            String bitmapUrl = DownloadImageTask.url;
            if ((bitmapUrl == null) || (!bitmapUrl.equals(url))) {
                bitmapDownloaderTask.cancel(true);
            } else {
                // The same URL is already being downloaded.
                return false;
            }
        }
        return true;
    }

    private static DownloadImageTask getBitmapDownloaderTask(ImageView imageView) {
        if (imageView != null) {
            Drawable drawable = imageView.getDrawable();
            if (drawable instanceof DownloadedDrawable) {
                DownloadedDrawable downloadedDrawable = (DownloadedDrawable)drawable;
                return downloadedDrawable.getBitmapDownloaderTask();
            }
        }
        return null;
    }

    private static class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        public static String url;
        private final WeakReference<ImageView> imageViewReference;
        String key;

        public DownloadImageTask(ImageView imageView) {
            imageViewReference = new WeakReference<ImageView>(imageView);
        }

        @Override
        protected Bitmap doInBackground(String... params) {
            Bitmap bitmap = null;
            try {
                String firstUrl = "https://s3-ap-northeast-1.amazonaws.com/" +
                        Constants.BUCKET_NAME + File.separator +
                        Constants.FOLDER_NAME_IN_S3_BUCKET + File.separator+
                        params[0];
                LogManager.printLog(getClass(), "firstUrl : " + firstUrl);
                url = params[0];
                InputStream in = new java.net.URL(firstUrl).openStream();

                //BitmapFactory.Options options = DecodeImage.getOptionsdecodeBitmapFromStream(new FlushedInputStream(in), 200 ,200);
                bitmap =  BitmapFactory.decodeStream(new FlushedInputStream(in));
               //bitmap = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                LogManager.printError(getClass(), e.getMessage());
                e.printStackTrace();
            }

            return  bitmap;
        }


        @Override
        protected void onPostExecute(Bitmap bitmap) {
            if (isCancelled()) {
                bitmap = null;
            }

            if (imageViewReference != null) {
                ImageView imageView = imageViewReference.get();
                if (imageView != null) {
                    if (bitmap != null) {
                        imageView.setImageBitmap(bitmap);
                        //CacheBitmap.addBitmapToMaemoryCache(key, bitmap);
                    } else {
                        imageView.setImageResource(R.drawable.btn_b);
                    }
                }
            }
        }
    }
    static class FlushedInputStream extends FilterInputStream {
        public FlushedInputStream(InputStream inputStream) {
            super(inputStream);
        }

        @Override
        public long skip(long n) throws IOException {
            long totalBytesSkipped = 0L;
            while (totalBytesSkipped < n) {
                long bytesSkipped = in.skip(n - totalBytesSkipped);
                if (bytesSkipped == 0L) {

                    int byte1 = read();

                    if (byte1 < 0) {
                        break;  // we reached EOF
                    } else {
                        bytesSkipped = 1; // we read one byte
                    }
                }
                totalBytesSkipped += bytesSkipped;
            }
            return totalBytesSkipped;
        }
    }
}
