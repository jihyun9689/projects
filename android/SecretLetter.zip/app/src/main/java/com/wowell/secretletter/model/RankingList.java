package com.wowell.secretletter.model;

public class RankingList {
	int number;
	String problem;
	String nickname;
	long timeLong;

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public String getProblem() {
		return problem;
	}
	public void setProblem(String problem) {
		this.problem = problem;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public long getTimeLong() {
		return timeLong;
	}
	public void setTimeLong(long timeLong) {
		this.timeLong = timeLong;
	}
	
	
}
