package com.wowell.secretletter.feature.intro;

import android.content.Intent;
import android.os.Bundle;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.TextView;

import com.wowell.secretletter.base.BaseActivity;
import com.wowell.secretletter.feature.login.SampleLoginActivity;
import com.wowell.secretletter.utils.logger.LogManager;

import com.wowell.secretletter.R;
/**
 * Created by kim on 2016-04-08.
 */
public class IntroActivity extends BaseActivity {
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);
        LogManager.printLog(getClass(), "introActivity");

        textView = (TextView)findViewById(R.id.intro_wowell_textview);
        AlphaAnimation alphaAnimation = new AlphaAnimation(0f, 1.0f);
        alphaAnimation.setDuration(500);
        alphaAnimation.setStartOffset(500);
        textView.setAnimation(alphaAnimation);


        alphaAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                Intent intent = new Intent(IntroActivity.this, SampleLoginActivity.class);
                startActivity(intent);
                finish();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }

}
