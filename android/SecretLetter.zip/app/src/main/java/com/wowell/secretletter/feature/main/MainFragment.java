package com.wowell.secretletter.feature.main;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.kakao.usermgmt.UserManagement;
import com.kakao.usermgmt.callback.LogoutResponseCallback;
import com.wowell.secretletter.R;
import com.wowell.secretletter.base.BaseFragment;
import com.wowell.secretletter.controller.StateController;
import com.wowell.secretletter.controller.UserInfoController;
import com.wowell.secretletter.feature.login.SampleLoginActivity;
import com.wowell.secretletter.feature.main.menu.ranking.RankingFragment;
import com.wowell.secretletter.feature.main.tabs.letterStorage.LetterStorageFragment;
import com.wowell.secretletter.feature.main.tabs.story.StoryFragmnet;
import com.wowell.secretletter.feature.main.tabs.todayLetter.TodayLetterFragment;
import com.wowell.secretletter.utils.logger.LogManager;

//import com.wowell.secretletter.base.state.ProblemState;

/**
 * Created by kim on 2016-03-22.
 */
public class MainFragment extends BaseFragment implements GcmListener{
    TabLayout tabs;
    ViewPager pager;
    PagerAdapter pagerAdapter;
    TodayLetterFragment todayLetterFragment;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_main, container, false);

        pager = (ViewPager)view.findViewById(R.id.main_viewpager);
        todayLetterFragment = new TodayLetterFragment();

        LogManager.printLog(getClass(), "onCreateView");
        init();
        return view;
    }

    @Override
    protected void init() {
        tabs = setTabLayout(true);
        setTiltle("Secret Letter");
        //((MainActivity)getActivity()).mainToolBarSetting();
        setHomeButtonBackPress(false);


        tabs.addTab(tabs.newTab().setText("오늘의 편지"));
        tabs.addTab(tabs.newTab().setText("편지 보관함"));
        tabs.addTab(tabs.newTab().setText("스토리"));

        //activity 안에 fragment를 사용하고 viewpager를 만들기 위해 fragment를 한번 더 삽입하니 꼬여버려서 viewpager가 사라지게 된다.
        //getFragmentManager 대신 getChildFragmentManager를 사용
        // the difference is that Fragment's now have their own internal FragmentManager that can handle Fragments.
        // The child FragmentManager is the one that handles Fragments contained within only the Fragment that it was added to.
        // The other FragmentManager is contained within the entire Activity.

        pagerAdapter = new ViewPagerAdapter(getChildFragmentManager());
        pager.setAdapter(pagerAdapter);
        pager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabs));

        //먼저 로딩하는 페이지의 갯수 설정
        pager.setOffscreenPageLimit(2);

        tabs.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                pager.setCurrentItem(tab.getPosition());

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
    }

    @Override
    public void onDetach() {
        super.onDetach();

    }

    @Override
    public void onResume() {
        super.onResume();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.findItem(R.id.menu_ranking).setVisible(true);
        menu.findItem(R.id.menu_setting).setVisible(true);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.menu_ranking) {
            RankingFragment rankingFragment = new RankingFragment();
            getMainActivity().replaceFragment(rankingFragment, true);

            return true;
        }else if(id == R.id.menu_setting){
            onClickLogout();
            Intent intent = new Intent(getActivity(), SampleLoginActivity.class);
            startActivity(intent);

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void onClickLogout() {
        UserManagement.requestLogout(new LogoutResponseCallback() {
            @Override
            public void onCompleteLogout() {
                //로그인 아웃
                // 로그인 페이지로 이동, state 초기화, 사용자 정보 초기화
                getMainActivity().redirectLoginActivity();
                StateController.initialzeState(getActivity());
                UserInfoController.deleteLocalStorage(getActivity());
            }
        });
    }

    @Override
    public void messageHandler(String message) {
        if(message.equals("receive")){
            //gcm 메세지를 받았을때
            LogManager.printLog(getClass(), "messageHandler");
            todayLetterFragment.messageHandler("receive");
        }
    }

    private class ViewPagerAdapter extends FragmentStatePagerAdapter {

        public ViewPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int position) {
            Fragment fragment = null;

            if(position == 0){
                fragment = todayLetterFragment;
            }else if(position == 1){
                fragment = new LetterStorageFragment();
            }else if(position == 2){
                fragment = new StoryFragmnet();
            }
            return fragment;
        }

        @Override
        public int getCount() {
            return 3;
        }
    }
}
