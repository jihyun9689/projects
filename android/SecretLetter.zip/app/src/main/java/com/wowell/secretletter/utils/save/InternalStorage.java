package com.wowell.secretletter.utils.save;

import android.content.Context;

import com.wowell.secretletter.utils.logger.LogManager;

import java.io.File;
import java.io.FilenameFilter;
import java.io.OutputStream;
import java.util.ArrayList;

/**
 * Created by kim on 2016-02-03.
 */
public class InternalStorage {
    static final String DIR_NAME = "internal_storage";

    public static File saveJpgFile(String name, Context context){
        String StorageDirectory = context.getFilesDir().toString();

        File dir = new File(StorageDirectory + "/" + DIR_NAME);
        dir.mkdirs();

        return new File(dir, name);
    }

    public static ArrayList<String> getFileNameList(Context context){ //알아 보기 쉽게 메소드 부터 시작합니다.
        ArrayList<String> fileArrayList = new ArrayList<>();

        try{
            LogManager.printLog(InternalStorage.class,"~~~~~~~~~~~~~~~~~~~fileList~~~~~~~~~~~~~~~~~~~~~~~");
            FilenameFilter fileFilter = new FilenameFilter(){  //이부분은 특정 확장자만 가지고 오고 싶을 경우 사용하시면 됩니다.
                public boolean accept(File dir, String name){
                    return name.endsWith("jpg") || name.endsWith("png");//이 부분에 사용하고 싶은 확장자를 넣으시면 됩니다.
                } //end accept
            };

            File file = new File(getFileDir(context)); //경로를 SD카드로 잡은거고 그 안에 있는 A폴더 입니다. 입맛에 따라 바꾸세요.
            File[] files = file.listFiles(fileFilter);//위에 만들어 두신 필터를 넣으세요. 만약 필요치 않으시면 fileFilter를 지우세요.
            for(File eachFile : files){
                fileArrayList.add(eachFile.getName());//루프로 돌면서 어레이에 하나씩 집어 넣습니다.
                LogManager.printLog(InternalStorage.class,eachFile.getName());
            }
            LogManager.printLog(InternalStorage.class,"~~~~~~~~~~~~~~~~~~~fileList~~~~~~~~~~~~~~~~~~~~~~~");
        }catch( Exception e ){
            LogManager.printLog(InternalStorage.class, e.getMessage());

        }

        return fileArrayList;
    }//end getTitleList

    public static String getFileDir(Context context) {
        String StorageDirectory = context.getFilesDir().toString();
        return StorageDirectory + "/"+ DIR_NAME;
    }

    public static boolean deleteFile( Context context, String name ){
        File file = new File(getFileDir(context) + File.separator + name);
        boolean bool = file.delete();

        getFileNameList(context);
        return  bool;
    }
}
